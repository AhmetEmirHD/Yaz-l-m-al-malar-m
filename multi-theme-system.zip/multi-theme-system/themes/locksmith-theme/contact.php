<?php
/**
 * Locksmith Theme - Contact Page
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('locksmith-theme');
$pageTitle = 'İletişim';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Contact Section -->
<section class="contact" style="padding: 6rem 0;">
    <div class="container">
        <div class="section-title">
            <h2>İletişim</h2>
            <p>7/24 acil çilingir hizmeti için bize ulaşın</p>
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem;">
            <div>
                <div style="background: white; padding: 2.5rem; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); margin-bottom: 2rem;">
                    <h3 style="margin-bottom: 1.5rem; color: var(--primary);">İletişim Bilgileri</h3>
                    
                    <div style="margin-bottom: 1.5rem;">
                        <i class="fas fa-phone" style="color: var(--primary); margin-right: 1rem;"></i>
                        <strong>Telefon:</strong> <?php echo getThemeSetting($theme['id'], 'phone', '0555 123 45 67'); ?>
                    </div>
                    
                    <div style="margin-bottom: 1.5rem;">
                        <i class="fas fa-map-marker-alt" style="color: var(--primary); margin-right: 1rem;"></i>
                        <strong>Adres:</strong> <?php echo getThemeSetting($theme['id'], 'address', 'İstanbul'); ?>
                    </div>
                    
                    <div style="margin-bottom: 1.5rem;">
                        <i class="fas fa-clock" style="color: var(--primary); margin-right: 1rem;"></i>
                        <strong>Çalışma Saatleri:</strong> 7/24 Hizmet
                    </div>
                </div>
                
                <div style="background: var(--primary); padding: 2rem; border-radius: 15px; text-align: center; color: white;">
                    <i class="fas fa-phone-volume fa-4x mb-3"></i>
                    <h3>Acil Durum?</h3>
                    <p style="font-size: 1.5rem; font-weight: 700; margin: 1rem 0;"><?php echo getThemeSetting($theme['id'], 'phone', '0555 123 45 67'); ?></p>
                    <a href="tel:<?php echo getThemeSetting($theme['id'], 'phone', '05551234567'); ?>" class="btn btn-white">
                        <i class="fas fa-phone"></i> Hemen Ara
                    </a>
                </div>
            </div>
            
            <div>
                <div style="background: white; padding: 2.5rem; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.08);">
                    <h3 style="margin-bottom: 1.5rem; color: var(--primary);">Mesaj Gönder</h3>
                    <form>
                        <div style="margin-bottom: 1.5rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Ad Soyad</label>
                            <input type="text" class="form-control" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 8px;">
                        </div>
                        <div style="margin-bottom: 1.5rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Telefon</label>
                            <input type="tel" class="form-control" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 8px;">
                        </div>
                        <div style="margin-bottom: 1.5rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Mesaj</label>
                            <textarea class="form-control" rows="4" style="width: 100%; padding: 0.75rem; border: 1px solid #ddd; border-radius: 8px;"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            <i class="fas fa-paper-plane"></i> Gönder
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
