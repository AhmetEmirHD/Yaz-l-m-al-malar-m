    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo getThemeSetting($theme['id'], 'brand_name', 'Çilingir'); ?>. Tüm hakları saklıdır.</p>
            <p>
                <i class="fas fa-phone"></i> <?php echo getThemeSetting($theme['id'], 'phone', '0555 123 45 67'); ?> | 
                <i class="fas fa-map-marker-alt"></i> <?php echo getThemeSetting($theme['id'], 'address', 'İstanbul'); ?>
            </p>
        </div>
    </footer>
</body>
</html>
