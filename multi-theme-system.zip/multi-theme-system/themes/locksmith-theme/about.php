<?php
/**
 * Locksmith Theme - About Page
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('locksmith-theme');
$pageTitle = 'Hakkımızda';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- About Section -->
<section class="about" style="padding: 6rem 0;">
    <div class="container">
        <div class="section-title">
            <h2>Hakkımızda</h2>
            <p>Profesyonel çilingir hizmetleri hakkında bilgi</p>
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center;">
            <div>
                <h3 style="font-size: 2rem; margin-bottom: 1.5rem; color: var(--primary);"><?php echo getThemeSetting($theme['id'], 'about_title', '10 Yıllık Tecrübe'); ?></h3>
                <p style="font-size: 1.1rem; line-height: 1.8; color: var(--secondary); margin-bottom: 1.5rem;">
                    <?php echo getThemeSetting($theme['id'], 'about_text', '2014 yılından bu yana profesyonel çilingir hizmetleri sunuyoruz. 7/24 acil servis, uzman kadro ve modern ekipmanlarımızla her zaman yanınızdayız.'); ?>
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8; color: var(--secondary);">
                    <?php echo getThemeSetting($theme['id'], 'about_text_2', 'Ev, ofis, araç ve ticari alanlarda kilit açma, anahtar çoğaltma ve kilit değişimi hizmetleri veriyoruz. Müşteri memnuniyeti bizim için en önemli önceliktir.'); ?>
                </p>
            </div>
            <div>
                <div style="background: var(--primary); padding: 3rem; border-radius: 20px; text-align: center; color: white;">
                    <i class="fas fa-shield-alt fa-5x mb-3"></i>
                    <h3 style="font-size: 3rem; margin-bottom: 1rem;">100%</h3>
                    <p>Müşteri Memnuniyeti</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
