<?php
/**
 * Locksmith Theme Layout
 */

// Get theme info
$theme = getThemeByFolder('locksmith-theme');
$pageTitle = isset($pageTitle) ? $pageTitle : 'Ana Sayfa';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <h1><?php echo getThemeSetting($theme['id'], 'hero_title', '7/24 Çilingir Hizmetleri'); ?></h1>
        <p><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Acil kapı açma, anahtar çoğaltma ve kilit değişimi hizmetleri.'); ?></p>
        <a href="tel:<?php echo getThemeSetting($theme['id'], 'phone', '05551234567'); ?>" class="btn btn-success">
            <i class="fas fa-phone"></i> <?php echo getThemeSetting($theme['id'], 'phone', '0555 123 45 67'); ?>
        </a>
        <a href="#services" class="btn btn-white" style="margin-left: 1rem;">
            <i class="fas fa-info-circle"></i> Hizmetlerimiz
        </a>
    </div>
</section>

<!-- Services Section -->
<section class="services" id="services">
    <div class="container">
        <div class="section-title">
            <h2>Hizmetlerimiz</h2>
            <p>Profesyonel çilingir hizmetleri ile her zaman yanınızdayız</p>
        </div>
        
        <div class="services-grid">
            <div class="service-card">
                <i class="fas fa-door-open"></i>
                <h3>Acil Kapı Açma</h3>
                <p>Ev, ofis ve araç kapılarınızı kırmadan açıyoruz. 7/24 acil servis.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-key"></i>
                <h3>Anahtar Çoğaltma</h3>
                <p>Tüm anahtar türleriniz için profesyonel çoğaltma hizmeti.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-lock"></i>
                <h3>Kilit Değişimi</h3>
                <p>Eski kilitlerinizi güvenli ve modern kilitlerle değiştiriyoruz.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-car"></i>
                <h3>Otomobil Çilingiri</h3>
                <p>Araba kapı açma ve anahtar yapımı hizmetleri.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-shield-alt"></i>
                <h3>Güvenlik Sistemleri</h3>
                <p>Kapı kilitleri, güvenlik kameraları ve alarm sistemleri.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-tools"></i>
                <h3>Tamir Bakım</h3>
                <p>Kilit tamiri ve bakım hizmetleri.</p>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta" id="contact">
    <div class="container">
        <h2><?php echo getThemeSetting($theme['id'], 'cta_title', 'Hemen Arayın'); ?></h2>
        <p><?php echo getThemeSetting($theme['id'], 'cta_subtitle', '7/24 acil çilingir hizmetimizle yanınızdayız.'); ?></p>
        <a href="tel:<?php echo getThemeSetting($theme['id'], 'phone', '05551234567'); ?>" class="btn btn-white">
            <i class="fas fa-phone"></i> <?php echo getThemeSetting($theme['id'], 'phone', '0555 123 45 67'); ?>
        </a>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
