<?php
/**
 * Locksmith Theme Admin Panel
 */

session_start();
// Check if logged in to main admin
require_once __DIR__ . '/../../../includes/functions.php';

requireAdminLogin();

$theme = getThemeByFolder('locksmith-theme');
$db = getDB();

$success = '';
$error = '';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle image upload
    if (isset($_FILES['hero_bg']) && $_FILES['hero_bg']['error'] === UPLOAD_ERR_OK) {
        $uploadedImage = uploadImage($_FILES['hero_bg'], 'locksmith');
        if ($uploadedImage) {
            setThemeSetting($theme['id'], 'hero_bg', $uploadedImage);
        }
    }
    
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $uploadedImage = uploadImage($_FILES['logo'], 'locksmith');
        if ($uploadedImage) {
            setThemeSetting($theme['id'], 'logo', $uploadedImage);
        }
    }
    
    // Handle color settings
    $colorSettings = [
        'primary_color' => sanitize($_POST['primary_color'] ?? '#ff6b35'),
        'secondary_color' => sanitize($_POST['secondary_color'] ?? '#2c3e50'),
        'accent_color' => sanitize($_POST['accent_color'] ?? '#27ae60')
    ];
    
    foreach ($colorSettings as $key => $value) {
        setThemeSetting($theme['id'], $key, $value);
    }
    
    // Handle text settings
    $textSettings = [
        'site_name' => sanitize($_POST['site_name'] ?? 'Çilingir Hizmetleri'),
        'brand_name' => sanitize($_POST['brand_name'] ?? 'Çilingir'),
        'phone' => sanitize($_POST['phone'] ?? '0555 123 45 67'),
        'address' => sanitize($_POST['address'] ?? 'İstanbul'),
        'hero_title' => sanitize($_POST['hero_title'] ?? '7/24 Çilingir Hizmetleri'),
        'hero_subtitle' => sanitize($_POST['hero_subtitle'] ?? 'Acil kapı açma, anahtar çoğaltma ve kilit değişimi hizmetleri.'),
        'cta_title' => sanitize($_POST['cta_title'] ?? 'Hemen Arayın'),
        'cta_subtitle' => sanitize($_POST['cta_subtitle'] ?? '7/24 acil çilingir hizmetimizle yanınızdayız.'),
        'about_title' => sanitize($_POST['about_title'] ?? '10 Yıllık Tecrübe'),
        'about_text' => sanitize($_POST['about_text'] ?? '2014 yılından bu yana profesyonel çilingir hizmetleri sunuyoruz.'),
        'about_text_2' => sanitize($_POST['about_text_2'] ?? 'Ev, ofis, araç ve ticari alanlarda kilit açma hizmetleri veriyoruz.')
    ];
    
    foreach ($textSettings as $key => $value) {
        setThemeSetting($theme['id'], $key, $value);
    }
    
    $success = 'Ayarlar başarıyla güncellendi.';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tema Admin | <?php echo $theme['name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: linear-gradient(135deg, #ff6b35 0%, #e55a2b 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 0.75rem 1.5rem;
            display: block;
            margin: 0.25rem 0;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.2);
        }
        .sidebar a i { margin-right: 0.75rem; width: 20px; }
        .card {
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            border: none;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-key fa-3x mb-2 text-white"></i>
                    <h5 class="text-white"><?php echo $theme['name']; ?></h5>
                    <small class="text-white-50">v<?php echo $theme['version']; ?></small>
                </div>
                <a href="index.php?page=home" class="<?php echo (isset($_GET['page']) && $_GET['page'] === 'home') || !isset($_GET['page']) ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Ana Sayfa
                </a>
                <a href="index.php?page=about" class="<?php echo isset($_GET['page']) && $_GET['page'] === 'about' ? 'active' : ''; ?>">
                    <i class="fas fa-info-circle"></i> Hakkımızda
                </a>
                <a href="index.php?page=contact" class="<?php echo isset($_GET['page']) && $_GET['page'] === 'contact' ? 'active' : ''; ?>">
                    <i class="fas fa-envelope"></i> İletişim
                </a>
                <a href="index.php?page=settings" class="<?php echo isset($_GET['page']) && $_GET['page'] === 'settings' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> Site Ayarları
                </a>
                <a href="<?php echo APP_URL; ?>/admin/dashboard.php">
                    <i class="fas fa-arrow-left"></i> Ana Admin
                </a>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Tema Ayarları</h2>
                    <a href="<?php echo APP_URL; ?>" target="_blank" class="btn btn-outline-primary">
                        <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                    </a>
                </div>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-sliders-h"></i> Genel Ayarlar</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <!-- Colors Section -->
                            <h6 class="mb-3"><i class="fas fa-palette"></i> Renk Ayarları</h6>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Ana Renk</label>
                                    <input type="color" name="primary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'primary_color', '#ff6b35'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">İkincil Renk</label>
                                    <input type="color" name="secondary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'secondary_color', '#2c3e50'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Vurgu Rengi</label>
                                    <input type="color" name="accent_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'accent_color', '#27ae60'); ?>">
                                </div>
                            </div>
                            
                            <hr>
                            
                            <!-- Images Section -->
                            <h6 class="mb-3"><i class="fas fa-image"></i> Resim Yükleme</h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Hero Arkaplanı</label>
                                    <input type="file" name="hero_bg" class="form-control" accept="image/*">
                                    <?php $heroBg = getThemeSetting($theme['id'], 'hero_bg'); ?>
                                    <?php if ($heroBg): ?>
                                        <img src="<?php echo getImageUrl($heroBg); ?>" style="max-width: 100px; margin-top: 0.5rem; border-radius: 8px;">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Logo</label>
                                    <input type="file" name="logo" class="form-control" accept="image/*">
                                    <?php $logo = getThemeSetting($theme['id'], 'logo'); ?>
                                    <?php if ($logo): ?>
                                        <img src="<?php echo getImageUrl($logo); ?>" style="max-width: 100px; margin-top: 0.5rem; border-radius: 8px;">
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <hr>
                            
                            <!-- General Settings -->
                            <h6 class="mb-3"><i class="fas fa-sliders-h"></i> Genel Ayarlar</h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Site Adı</label>
                                    <input type="text" name="site_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'site_name', 'Çilingir Hizmetleri'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Marka Adı</label>
                                    <input type="text" name="brand_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'brand_name', 'Çilingir'); ?>">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Telefon</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'phone', '0555 123 45 67'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Adres</label>
                                    <input type="text" name="address" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'address', 'İstanbul'); ?>">
                                </div>
                            </div>
                            
                            <hr>
                            
                            <!-- Hero Section -->
                            <h6 class="mb-3"><i class="fas fa-flag"></i> Hero Bölümü</h6>
                            <div class="mb-3">
                                <label class="form-label">Ana Başlık</label>
                                <input type="text" name="hero_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title', '7/24 Çilingir Hizmetleri'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="hero_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Acil kapı açma, anahtar çoğaltma ve kilit değişimi hizmetleri.'); ?></textarea>
                            </div>
                            
                            <hr>
                            
                            <!-- About Section -->
                            <h6 class="mb-3"><i class="fas fa-info-circle"></i> Hakkımızda Bölümü</h6>
                            <div class="mb-3">
                                <label class="form-label">Başlık</label>
                                <input type="text" name="about_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_title', '10 Yıllık Tecrübe'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Metin 1</label>
                                <textarea name="about_text" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'about_text', '2014 yılından bu yana profesyonel çilingir hizmetleri sunuyoruz.'); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Metin 2</label>
                                <textarea name="about_text_2" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'about_text_2', 'Ev, ofis, araç ve ticari alanlarda kilit açma hizmetleri veriyoruz.'); ?></textarea>
                            </div>
                            
                            <hr>
                            
                            <!-- CTA Section -->
                            <h6 class="mb-3"><i class="fas fa-bullhorn"></i> CTA Bölümü</h6>
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'cta_title', 'Hemen Arayın'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'cta_subtitle', '7/24 acil çilingir hizmetimizle yanınızdayız.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                <?php elseif ($page === 'home'): ?>
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-home"></i> Ana Sayfa Ayarları</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <h6 class="mb-3">Hero Bölümü</h6>
                            <div class="mb-3">
                                <label class="form-label">Ana Başlık</label>
                                <input type="text" name="hero_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title', '7/24 Çilingir Hizmetleri'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="hero_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Acil kapı açma, anahtar çoğaltma ve kilit değişimi hizmetleri.'); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Hero Arkaplanı</label>
                                <input type="file" name="hero_bg" class="form-control" accept="image/*">
                                <?php $heroBg = getThemeSetting($theme['id'], 'hero_bg'); ?>
                                <?php if ($heroBg): ?>
                                    <img src="<?php echo getImageUrl($heroBg); ?>" style="max-width: 200px; margin-top: 0.5rem; border-radius: 8px;">
                                <?php endif; ?>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                <?php elseif ($page === 'about'): ?>
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle"></i> Hakkımızda Ayarları</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Başlık</label>
                                <input type="text" name="about_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_title', '10 Yıllık Tecrübe'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Metin 1</label>
                                <textarea name="about_text" class="form-control" rows="4"><?php echo getThemeSetting($theme['id'], 'about_text', '2014 yılından bu yana profesyonel çilingir hizmetleri sunuyoruz.'); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Metin 2</label>
                                <textarea name="about_text_2" class="form-control" rows="4"><?php echo getThemeSetting($theme['id'], 'about_text_2', 'Ev, ofis, araç ve ticari alanlarda kilit açma hizmetleri veriyoruz.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                <?php elseif ($page === 'contact'): ?>
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-envelope"></i> İletişim Ayarları</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label">Telefon</label>
                                <input type="text" name="phone" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'phone', '0555 123 45 67'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Adres</label>
                                <input type="text" name="address" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'address', 'İstanbul'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'cta_title', 'Hemen Arayın'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'cta_subtitle', '7/24 acil çilingir hizmetimizle yanınızdayız.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
