<?php
/**
 * Carpet Theme - Contact Page
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('carpet-theme');
$pageTitle = 'İletişim';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Page Hero -->
<section class="page-hero">
    <div class="page-hero-content">
        <h1>İletişim</h1>
        <p>Size yardımcı olmaktan mutluluk duyarız</p>
    </div>
</section>

<!-- Contact Section -->
<section class="contact-section">
    <div class="container">
        <div class="contact-grid">
            <div class="contact-info">
                <h2>Bize Ulaşın</h2>
                
                <div class="contact-card">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <h4>Adres</h4>
                        <p><?php echo getThemeSetting($theme['id'], 'address', 'Halıcılar Caddesi No:123, Fatih/İstanbul'); ?></p>
                    </div>
                </div>
                
                <div class="contact-card">
                    <i class="fas fa-phone"></i>
                    <div>
                        <h4>Telefon</h4>
                        <p><?php echo getThemeSetting($theme['id'], 'phone', '0212 555 55 55'); ?></p>
                    </div>
                </div>
                
                <div class="contact-card">
                    <i class="fas fa-envelope"></i>
                    <div>
                        <h4>E-posta</h4>
                        <p><?php echo getThemeSetting($theme['id'], 'email', 'info@elitehali.com'); ?></p>
                    </div>
                </div>
                
                <div class="contact-card">
                    <i class="fas fa-clock"></i>
                    <div>
                        <h4>Çalışma Saatleri</h4>
                        <p>Pazartesi-Cumartesi: 09:00 - 19:00</p>
                        <p>Pazar: Kapalı</p>
                    </div>
                </div>
            </div>
            
            <div class="contact-form-wrapper">
                <h3>Bize Mesaj Gönderin</h3>
                <form>
                    <div class="form-group">
                        <label>Ad Soyad</label>
                        <input type="text" placeholder="Adınız ve soyadınız">
                    </div>
                    <div class="form-group">
                        <label>E-posta</label>
                        <input type="email" placeholder="E-posta adresiniz">
                    </div>
                    <div class="form-group">
                        <label>Telefon</label>
                        <input type="tel" placeholder="Telefon numaranız">
                    </div>
                    <div class="form-group">
                        <label>Konu</label>
                        <input type="text" placeholder="Mesaj konusu">
                    </div>
                    <div class="form-group">
                        <label>Mesajınız</label>
                        <textarea rows="5" placeholder="Mesajınızı yazın..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%; background: var(--primary); color: var(--white);">
                        <i class="fas fa-paper-plane"></i> Gönder
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="cta-content">
        <h2>Mağazamızı Ziyaret Edin</h2>
        <p>Showroom'umuzda yüzlerce halı ve kilim modelini canlı olarak inceleyebilirsiniz.</p>
        <a href="<?php echo getThemeSetting($theme['id'], 'maps_link', '#'); ?>" class="btn" style="background: var(--primary-dark); color: var(--accent);">
            <i class="fas fa-map-marked-alt"></i> Yol Tarifi Al
        </a>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
