<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' : ''; ?><?php echo getThemeSetting($theme['id'], 'site_name', 'Elite Halı & Kilim'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Cormorant+Garamond:wght@400;500;600&family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: <?php echo getThemeSetting($theme['id'], 'primary_color', '#8B4513'); ?>;
            --primary-light: <?php echo getThemeSetting($theme['id'], 'primary_color', '#A0522D'); ?>;
            --primary-dark: <?php echo getThemeSetting($theme['id'], 'primary_color', '#654321'); ?>;
            --secondary: <?php echo getThemeSetting($theme['id'], 'secondary_color', '#2C3E50'); ?>;
            --accent: <?php echo getThemeSetting($theme['id'], 'accent_color', '#D4AF37'); ?>;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container">
            <a href="/multi-theme-system" class="navbar-brand">
                <i class="fas fa-rug"></i>
                <span><?php echo getThemeSetting($theme['id'], 'brand_name', 'Elite Halı'); ?></span>
            </a>
            <ul class="navbar-nav">
                <li><a href="/multi-theme-system">Ana Sayfa</a></li>
                <li><a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/about.php">Hakkımızda</a></li>
                <li><a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/contact.php">İletişim</a></li>
                <li><a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>" class="btn btn-primary" style="padding: 0.75rem 1.5rem; font-size: 0.85rem;">
                    <i class="fas fa-shopping-cart"></i> Mağaza
                </a></li>
            </ul>
        </div>
    </nav>
