<?php
/**
 * Carpet Theme Admin Panel
 */

session_start();
require_once __DIR__ . '/../../../includes/functions.php';

requireAdminLogin();

$theme = getThemeByFolder('carpet-theme');
$db = getDB();

$success = '';
$error = '';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle image uploads
    $imageFields = ['hero_bg', 'logo', 'about_image'];
    for ($i = 1; $i <= 6; $i++) {
        $imageFields[] = 'product_' . $i . '_image';
    }
    
    foreach ($imageFields as $field) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
            $uploadedImage = uploadImage($_FILES[$field], 'carpet');
            if ($uploadedImage) {
                setThemeSetting($theme['id'], $field, $uploadedImage);
            }
        }
    }
    
    // Handle color settings
    $colorSettings = [
        'primary_color' => sanitize($_POST['primary_color'] ?? '#8B4513'),
        'secondary_color' => sanitize($_POST['secondary_color'] ?? '#2C3E50'),
        'accent_color' => sanitize($_POST['accent_color'] ?? '#D4AF37')
    ];
    
    foreach ($colorSettings as $key => $value) {
        setThemeSetting($theme['id'], $key, $value);
    }
    
    // Handle text settings based on page
    $page = $_POST['current_page'] ?? 'home';
    
    if ($page === 'settings') {
        $textSettings = [
            'site_name' => sanitize($_POST['site_name'] ?? 'Elite Halı & Kilim'),
            'brand_name' => sanitize($_POST['brand_name'] ?? 'Elite Halı'),
            'footer_text' => sanitize($_POST['footer_text'] ?? '1990\'dan beri kaliteli ve özgün halı koleksiyonları.'),
            'phone' => sanitize($_POST['phone'] ?? '0212 555 55 55'),
            'email' => sanitize($_POST['email'] ?? 'info@elitehali.com'),
            'address' => sanitize($_POST['address'] ?? 'Halıcılar Caddesi No:123, Fatih/İstanbul'),
            'shop_link' => sanitize($_POST['shop_link'] ?? '#'),
            'maps_link' => sanitize($_POST['maps_link'] ?? '#')
        ];
    } elseif ($page === 'home') {
        $textSettings = [
            'hero_title' => sanitize($_POST['hero_title'] ?? 'Evinize'),
            'hero_title_span' => sanitize($_POST['hero_title_span'] ?? 'Şıklık Katın'),
            'hero_subtitle' => sanitize($_POST['hero_subtitle'] ?? 'El işi halı ve kilim koleksiyonlarımızla yaşam alanlarınıza zarafet katın.'),
            'products_title' => sanitize($_POST['products_title'] ?? 'Seçkin Halılarımız'),
            'products_subtitle' => sanitize($_POST['products_subtitle'] ?? 'Özel Koleksiyon'),
            'products_desc' => sanitize($_POST['products_desc'] ?? 'Her biri özenle seçilmiş, el dokuması ve modern halı koleksiyonumuzu keşfedin.'),
            'features_title' => sanitize($_POST['features_title'] ?? 'Farkımızı Keşfedin'),
            'cta_title' => sanitize($_POST['cta_title'] ?? 'Özel Sipariş için Bize Ulaşın'),
            'cta_subtitle' => sanitize($_POST['cta_subtitle'] ?? 'İstediğiniz ölçü, renk ve desende özel halı üretimi yapıyoruz.')
        ];
        
        // Product prices
        for ($i = 1; $i <= 6; $i++) {
            $textSettings['product_' . $i . '_price'] = sanitize($_POST['product_' . $i . '_price'] ?? '');
            if ($i == 3) {
                $textSettings['product_' . $i . '_old_price'] = sanitize($_POST['product_' . $i . '_old_price'] ?? '');
            }
        }
    } elseif ($page === 'about') {
        $textSettings = [
            'about_title' => sanitize($_POST['about_title'] ?? 'Geleneksel'),
            'about_title_span' => sanitize($_POST['about_title_span'] ?? 'Ustalık'),
            'about_text_1' => sanitize($_POST['about_text_1'] ?? '1990 yılında küçük bir atölyede başlayan yolculuğumuz, bugün Türkiye\'nin önde gelen halı markalarından biri olma yolunda devam ediyor.'),
            'about_text_2' => sanitize($_POST['about_text_2'] ?? 'Anadolu\'nun zengin dokuma kültürünü modern tasarım anlayışıyla birleştirerek koleksiyonlar üretiyoruz.'),
            'about_text_3' => sanitize($_POST['about_text_3'] ?? 'Misyonumuz, müşterilerimize sadece bir halı değil, bir sanat eseri ve nesiller boyu aktarılacak bir miras sunmaktır.')
        ];
    }
    
    if (isset($textSettings)) {
        foreach ($textSettings as $key => $value) {
            setThemeSetting($theme['id'], $key, $value);
        }
    }
    
    $success = 'Ayarlar başarıyla güncellendi.';
}

$page = $_GET['page'] ?? 'home';
$pageTitles = [
    'home' => 'Ana Sayfa Ayarları',
    'about' => 'Hakkımızda Ayarları',
    'contact' => 'İletişim Ayarları',
    'settings' => 'Site Ayarları'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tema Admin | <?php echo $theme['name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Cormorant+Garamond:wght@400;500;600&family=Montserrat:wght@300;400;500;600&display=swap');
        
        body { 
            background: #FAEBD7; 
            font-family: 'Montserrat', sans-serif;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #8B4513 0%, #654321 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 1rem 1.5rem;
            display: block;
            margin: 0.25rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background: rgba(212, 175, 55, 0.2);
            color: #D4AF37;
        }
        
        .sidebar a i { 
            margin-right: 0.75rem; 
            width: 20px;
            color: #D4AF37;
        }
        
        .card {
            border-radius: 0;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            border: none;
        }
        
        .card-header {
            background: linear-gradient(135deg, #8B4513 0%, #A0522D 100%);
            color: #D4AF37;
            border-radius: 0 !important;
            padding: 1.5rem;
        }
        
        .card-header h5 {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            font-size: 1.3rem;
        }
        
        .form-label {
            font-weight: 600;
            color: #2C3E50;
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-control-color {
            border-radius: 0;
            border: 2px solid #FAEBD7;
            padding: 0.75rem 1rem;
        }
        
        .form-control:focus {
            border-color: #D4AF37;
            box-shadow: 0 0 0 0.2rem rgba(212, 175, 55, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #8B4513 0%, #A0522D 100%);
            border: none;
            border-radius: 0;
            padding: 0.75rem 2rem;
            font-weight: 600;
            color: #fff;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #A0522D 0%, #8B4513 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(139, 69, 19, 0.4);
        }
        
        .image-preview {
            max-width: 150px;
            border: 3px solid #D4AF37;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .section-divider {
            border-top: 2px solid #FAEBD7;
            margin: 2rem 0;
        }
        
        h2 {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
        }
        
        .product-row {
            background: #FAEBD7;
            padding: 1.5rem;
            margin-bottom: 1rem;
            border-left: 4px solid #8B4513;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar">
                <div class="text-center mb-5">
                    <i class="fas fa-rug fa-3x mb-3" style="color: #D4AF37;"></i>
                    <h5 class="text-white" style="font-family: 'Playfair Display', serif;"><?php echo $theme['name']; ?></h5>
                    <small class="text-white-50">v<?php echo $theme['version']; ?></small>
                </div>
                
                <a href="index.php?page=home" class="<?php echo $page === 'home' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Ana Sayfa
                </a>
                <a href="index.php?page=about" class="<?php echo $page === 'about' ? 'active' : ''; ?>">
                    <i class="fas fa-info-circle"></i> Hakkımızda
                </a>
                <a href="index.php?page=contact" class="<?php echo $page === 'contact' ? 'active' : ''; ?>">
                    <i class="fas fa-envelope"></i> İletişim
                </a>
                <a href="index.php?page=settings" class="<?php echo $page === 'settings' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> Site Ayarları
                </a>
                
                <div class="mt-5">
                    <a href="<?php echo APP_URL; ?>/admin/dashboard.php">
                        <i class="fas fa-arrow-left"></i> Ana Admin
                    </a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 style="font-family: 'Playfair Display', serif; font-weight: 700; color: #8B4513;">
                        <?php echo $pageTitles[$page] ?? 'Tema Ayarları'; ?>
                    </h2>
                    <a href="<?php echo APP_URL; ?>" target="_blank" class="btn btn-outline-primary" style="border-color: #8B4513; color: #8B4513;">
                        <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                    </a>
                </div>
                
                <?php if ($success): ?>
                    <div class="alert alert-success" style="border-radius: 0; border-left: 4px solid #8B4513;">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <!-- HOME PAGE SETTINGS -->
                <?php if ($page === 'home'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-home"></i> Ana Sayfa İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="home">
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-image"></i> Hero Bölümü
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Hero Arkaplanı</label>
                                    <input type="file" name="hero_bg" class="form-control" accept="image/*">
                                    <?php $heroBg = getThemeSetting($theme['id'], 'hero_bg'); ?>
                                    <?php if ($heroBg): ?>
                                        <img src="<?php echo getImageUrl($heroBg); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Ana Başlık</label>
                                    <input type="text" name="hero_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title', 'Evinize'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Renkli Span</label>
                                    <input type="text" name="hero_title_span" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title_span', 'Şıklık Katın'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="hero_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'El işi halı ve kilim koleksiyonlarımızla yaşam alanlarınıza zarafet katın.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-rug"></i> Ürünler Bölümü
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Bölüm Başlığı</label>
                                    <input type="text" name="products_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'products_title', 'Seçkin Halılarımız'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="products_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'products_subtitle', 'Özel Koleksiyon'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Açıklama</label>
                                <textarea name="products_desc" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'products_desc', 'Her biri özenle seçilmiş, el dokuması ve modern halı koleksiyonumuzu keşfedin.'); ?></textarea>
                            </div>
                            
                            <!-- Product Images & Prices -->
                            <?php for ($i = 1; $i <= 6; $i++): ?>
                            <div class="product-row">
                                <h6 style="color: #8B4513; font-weight: 600; margin-bottom: 1rem;">Ürün <?php echo $i; ?></h6>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Ürün Görseli</label>
                                        <input type="file" name="product_<?php echo $i; ?>_image" class="form-control" accept="image/*">
                                        <?php $prodImg = getThemeSetting($theme['id'], 'product_' . $i . '_image'); ?>
                                        <?php if ($prodImg): ?>
                                            <img src="<?php echo getImageUrl($prodImg); ?>" class="image-preview mt-2" style="max-width: 100px;">
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Fiyat (TL)</label>
                                        <input type="text" name="product_<?php echo $i; ?>_price" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'product_' . $i . '_price'); ?>">
                                    </div>
                                    <?php if ($i == 3): ?>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Eski Fiyat (İndirim için)</label>
                                        <input type="text" name="product_<?php echo $i; ?>_old_price" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'product_' . $i . '_old_price'); ?>">
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endfor; ?>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-star"></i> Özellikler Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Bölüm Başlığı</label>
                                <input type="text" name="features_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'features_title', 'Farkımızı Keşfedin'); ?>">
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-bullhorn"></i> CTA Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'cta_title', 'Özel Sipariş için Bize Ulaşın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'İstediğiniz ölçü, renk ve desende özel halı üretimi yapıyoruz.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- ABOUT PAGE SETTINGS -->
                <?php elseif ($page === 'about'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-info-circle"></i> Hakkımızda İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="about">
                            
                            <div class="mb-3">
                                <label class="form-label">Hakkımızda Görseli</label>
                                <input type="file" name="about_image" class="form-control" accept="image/*">
                                <?php $aboutImg = getThemeSetting($theme['id'], 'about_image'); ?>
                                <?php if ($aboutImg): ?>
                                    <img src="<?php echo getImageUrl($aboutImg); ?>" class="image-preview mt-2">
                                <?php endif; ?>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Ana Başlık</label>
                                    <input type="text" name="about_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_title', 'Geleneksel'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Renkli Span</label>
                                    <input type="text" name="about_title_span" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_title_span', 'Ustalık'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 1</label>
                                <textarea name="about_text_1" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'about_text_1', '1990 yılında küçük bir atölyede başlayan yolculuğumuz, bugün Türkiye\'nin önde gelen halı markalarından biri olma yolunda devam ediyor.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 2</label>
                                <textarea name="about_text_2" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'about_text_2', 'Anadolu\'nun zengin dokuma kültürünü modern tasarım anlayışıyla birleştirerek koleksiyonlar üretiyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 3</label>
                                <textarea name="about_text_3" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'about_text_3', 'Misyonumuz, müşterilerimize sadece bir halı değil, bir sanat eseri ve nesiller boyu aktarılacak bir miras sunmaktır.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- CONTACT PAGE SETTINGS -->
                <?php elseif ($page === 'contact'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-envelope"></i> İletişim Bilgileri</h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="alert alert-info" style="border-radius: 0; border-left: 4px solid #D4AF37;">
                            <i class="fas fa-info-circle"></i> İletişim bilgileri "Site Ayarları" bölümünden düzenlenir.
                        </div>
                        <a href="index.php?page=settings" class="btn btn-primary">
                            <i class="fas fa-cog"></i> Site Ayarlarına Git
                        </a>
                    </div>
                </div>
                
                <!-- SITE SETTINGS -->
                <?php elseif ($page === 'settings'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-cog"></i> Genel Site Ayarları</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="settings">
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-palette"></i> Renk Ayarları
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Ana Renk (Kahverengi)</label>
                                    <input type="color" name="primary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'primary_color', '#8B4513'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">İkincil Renk (Koyu)</label>
                                    <input type="color" name="secondary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'secondary_color', '#2C3E50'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Vurgu Rengi (Altın)</label>
                                    <input type="color" name="accent_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'accent_color', '#D4AF37'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-image"></i> Logo
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Logo</label>
                                <input type="file" name="logo" class="form-control" accept="image/*">
                                <?php $logo = getThemeSetting($theme['id'], 'logo'); ?>
                                <?php if ($logo): ?>
                                    <img src="<?php echo getImageUrl($logo); ?>" class="image-preview mt-2">
                                <?php endif; ?>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-info-circle"></i> Site Bilgileri
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Site Adı</label>
                                    <input type="text" name="site_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'site_name', 'Elite Halı & Kilim'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Marka Adı</label>
                                    <input type="text" name="brand_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'brand_name', 'Elite Halı'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Footer Metni</label>
                                <textarea name="footer_text" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'footer_text', '1990\'dan beri kaliteli ve özgün halı koleksiyonları. Geleneksel el işçiliği ve modern tasarımın mükemmel birleşimi.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-address-card"></i> İletişim Bilgileri
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Telefon</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'phone', '0212 555 55 55'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">E-posta</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'email', 'info@elitehali.com'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Adres</label>
                                <textarea name="address" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'address', 'Halıcılar Caddesi No:123, Fatih/İstanbul'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #8B4513; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-link"></i> Linkler
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Mağaza Linki</label>
                                    <input type="text" name="shop_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>">
                                    <small class="text-muted">Ürünler/Mağaza butonuna tıklandığında yönlendirilecek link</small>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Harita Linki</label>
                                    <input type="text" name="maps_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'maps_link', '#'); ?>">
                                    <small class="text-muted">Yol Tarifi Al butonu için Google Maps linki</small>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
