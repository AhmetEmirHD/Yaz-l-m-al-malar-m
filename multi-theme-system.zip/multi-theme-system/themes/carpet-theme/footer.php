    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <h3><i class="fas fa-rug"></i> <?php echo getThemeSetting($theme['id'], 'brand_name', 'Elite Halı'); ?></h3>
                    <p><?php echo getThemeSetting($theme['id'], 'footer_text', '1990\'dan beri kaliteli ve özgün halı koleksiyonları. Geleneksel el işçiliği ve modern tasarımın mükemmel birleşimi.'); ?></p>
                </div>
                <div class="footer-contact">
                    <h4>İletişim</h4>
                    <p><i class="fas fa-map-marker-alt" style="color: var(--accent); margin-right: 0.5rem;"></i> <?php echo getThemeSetting($theme['id'], 'address', 'İstanbul, Türkiye'); ?></p>
                    <p><i class="fas fa-phone" style="color: var(--accent); margin-right: 0.5rem;"></i> <?php echo getThemeSetting($theme['id'], 'phone', '0212 555 55 55'); ?></p>
                    <p><i class="fas fa-envelope" style="color: var(--accent); margin-right: 0.5rem;"></i> <?php echo getThemeSetting($theme['id'], 'email', 'info@elitehali.com'); ?></p>
                    <p><i class="fas fa-clock" style="color: var(--accent); margin-right: 0.5rem;"></i> Pazartesi-Cumartesi: 09:00 - 19:00</p>
                </div>
                <div class="footer-links">
                    <h4>Hızlı Linkler</h4>
                    <a href="<?php echo APP_URL; ?>">Ana Sayfa</a>
                    <a href="<?php echo APP_URL; ?>/themes/<?php echo $theme['folder']; ?>/about.php">Hakkımızda</a>
                    <a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>">Ürünler</a>
                    <a href="<?php echo APP_URL; ?>/themes/<?php echo $theme['folder']; ?>/contact.php">İletişim</a>
                </div>
                <div>
                    <h4>Bizi Takip Edin</h4>
                    <div class="footer-social">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-whatsapp"></i></a>
                        <a href="#"><i class="fab fa-pinterest"></i></a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo getThemeSetting($theme['id'], 'brand_name', 'Elite Halı'); ?>. Tüm hakları saklıdır.</p>
            </div>
        </div>
    </footer>
</body>
</html>
