<?php
/**
 * Carpet Theme - About Page
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('carpet-theme');
$pageTitle = 'Hakkımızda';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Page Hero -->
<section class="page-hero">
    <div class="page-hero-content">
        <h1>Hakkımızda</h1>
        <p>35 yıllık tecrübemizle kaliteli halı ve kilim üretiyoruz</p>
    </div>
</section>

<!-- About Section -->
<section class="about-section">
    <div class="container">
        <div class="about-content">
            <div class="about-image">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'about_image')) ?: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800'; ?>" alt="Halı Mağazası">
            </div>
            <div class="about-text">
                <h2>
                    <?php echo getThemeSetting($theme['id'], 'about_title', 'Geleneksel'); ?>
                    <span><?php echo getThemeSetting($theme['id'], 'about_title_span', 'Ustalık'); ?></span>
                </h2>
                <p><?php echo getThemeSetting($theme['id'], 'about_text_1', '1990 yılında küçük bir atölyede başlayan yolculuğumuz, bugün Türkiye\'nin önde gelen halı ve kilim markalarından biri olma yolunda devam ediyor. Üç nesildir süregelen halıcılık geleneğimiz, her bir ürünümüzde kendini gösteriyor.'); ?></p>
                <p><?php echo getThemeSetting($theme['id'], 'about_text_2', 'Anadolu\'nun zengin dokuma kültürünü modern tasarım anlayışıyla birleştirerek, hem geleneksel hem de çağdaş yaşam alanlarına uygun koleksiyonlar üretiyoruz. Her halımız, ustalarımızın yılların getirdiği tecrübesi ve özenle işleniyor.'); ?></p>
                <p><?php echo getThemeSetting($theme['id'], 'about_text_3', 'Misyonumuz, müşterilerimize sadece bir halı değil, bir sanat eseri ve nesiller boyu aktarılacak bir miras sunmaktır. Kalite ve müşteri memnuniyeti odaklı çalışma prensibimizle, her projeyi özenle tamamlıyoruz.'); ?></p>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="features" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);">
    <div class="container">
        <div class="section-header" style="color: white;">
            <h6 style="color: var(--accent);">Rakamlarla Biz</h6>
            <h2 style="color: white;">Başarılarımız</h2>
        </div>
        
        <div class="features-grid" style="grid-template-columns: repeat(4, 1fr);">
            <div class="feature-box" style="text-align: center; background: rgba(255,255,255,0.1);">
                <div class="feature-icon" style="margin: 0 auto 1.5rem;">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <h3 style="font-size: 3rem; margin-bottom: 0.5rem;">35+</h3>
                <p>Yıllık Deneyim</p>
            </div>
            
            <div class="feature-box" style="text-align: center; background: rgba(255,255,255,0.1);">
                <div class="feature-icon" style="margin: 0 auto 1.5rem;">
                    <i class="fas fa-users"></i>
                </div>
                <h3 style="font-size: 3rem; margin-bottom: 0.5rem;">50K+</h3>
                <p>Mutlu Müşteri</p>
            </div>
            
            <div class="feature-box" style="text-align: center; background: rgba(255,255,255,0.1);">
                <div class="feature-icon" style="margin: 0 auto 1.5rem;">
                    <i class="fas fa-rug"></i>
                </div>
                <h3 style="font-size: 3rem; margin-bottom: 0.5rem;">10K+</h3>
                <p>Ürün Çeşidi</p>
            </div>
            
            <div class="feature-box" style="text-align: center; background: rgba(255,255,255,0.1);">
                <div class="feature-icon" style="margin: 0 auto 1.5rem;">
                    <i class="fas fa-award"></i>
                </div>
                <h3 style="font-size: 3rem; margin-bottom: 0.5rem;">15</h3>
                <p>Ödül</p>
            </div>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
