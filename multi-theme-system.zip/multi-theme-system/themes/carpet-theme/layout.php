<?php
/**
 * Carpet Theme - Main Layout (Home Page)
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('carpet-theme');
$pageTitle = 'Ana Sayfa';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <div class="hero-badge">
            <i class="fas fa-award"></i> 35 Yıllık Deneyim
        </div>
        <h1>
            <?php echo getThemeSetting($theme['id'], 'hero_title', 'Evinize'); ?>
            <span><?php echo getThemeSetting($theme['id'], 'hero_title_span', 'Şıklık Katın'); ?></span>
        </h1>
        <p><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'El işi halı ve kilim koleksiyonlarımızla yaşam alanlarınıza zarafet katın. Geleneksel dokunuş, modern estetik.'); ?></p>
        <div class="hero-buttons">
            <a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>" class="btn btn-primary">
                <i class="fas fa-eye"></i> Koleksiyonu Keşfet
            </a>
            <a href="<?php echo APP_URL; ?>/themes/<?php echo $theme['folder']; ?>/contact.php" class="btn btn-outline">
                <i class="fas fa-phone"></i> Bize Ulaşın
            </a>
        </div>
    </div>
</section>

<!-- Products Section -->
<section class="products" id="products">
    <div class="container">
        <div class="section-header">
            <h6><?php echo getThemeSetting($theme['id'], 'products_subtitle', 'Özel Koleksiyon'); ?></h6>
            <h2><?php echo getThemeSetting($theme['id'], 'products_title', 'Seçkin Halılarımız'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'products_desc', 'Her biri özenle seçilmiş, el dokuması ve modern halı koleksiyonumuzu keşfedin.'); ?></p>
        </div>
        
        <div class="products-grid">
            <!-- Product 1 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'product_1_image')) ?: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500'; ?>" alt="El Dokuma Halı">
                    <span class="product-badge">El Dokuma</span>
                </div>
                <div class="product-content">
                    <p class="product-category">Klasik Koleksiyon</p>
                    <h3 class="product-title">Hereke İpek Halı</h3>
                    <p class="product-description">Geleneksel Hereke dokuma tekniği ile üretilmiş, ipek iplikli şahane bir eser.</p>
                    <p class="product-price"><?php echo getThemeSetting($theme['id'], 'product_1_price', '12.500'); ?> TL</p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>" class="product-btn">Detayları Gör</a>
                </div>
            </div>
            
            <!-- Product 2 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'product_2_image')) ?: 'https://images.unsplash.com/photo-1564078516393-cf04bd966897?w=500'; ?>" alt="Modern Halı">
                </div>
                <div class="product-content">
                    <p class="product-category">Modern Koleksiyon</p>
                    <h3 class="product-title">Geometrik Desen Halı</h3>
                    <p class="product-description">Modern yaşam alanları için özel tasarlanmış, geometrik desenli yün halı.</p>
                    <p class="product-price"><?php echo getThemeSetting($theme['id'], 'product_2_price', '4.800'); ?> TL</p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>" class="product-btn">Detayları Gör</a>
                </div>
            </div>
            
            <!-- Product 3 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'product_3_image')) ?: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500'; ?>" alt="Kilim">
                    <span class="product-badge">Özel Fiyat</span>
                </div>
                <div class="product-content">
                    <p class="product-category">Kilim Koleksiyonu</p>
                    <h3 class="product-title">Anadolu Motifli Kilim</h3>
                    <p class="product-description">Anadolu'nun zengin motifleriyle süslenmiş, el dokuması özel kilim.</p>
                    <p class="product-price"><?php echo getThemeSetting($theme['id'], 'product_3_price', '2.900'); ?> TL <span><?php echo getThemeSetting($theme['id'], 'product_3_old_price', '3.500'); ?> TL</span></p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>" class="product-btn">Detayları Gör</a>
                </div>
            </div>
            
            <!-- Product 4 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'product_4_image')) ?: 'https://images.unsplash.com/photo-1600166898405-da9535204843?w=500'; ?>" alt="Pers Halı">
                    <span class="product-badge">İthal</span>
                </div>
                <div class="product-content">
                    <p class="product-category">İthal Koleksiyon</p>
                    <h3 class="product-title">Pers İpek Halı</h3>
                    <p class="product-description">İran'dan özel ithal edilmiş, ipek iplikli lüks Pers halısı.</p>
                    <p class="product-price"><?php echo getThemeSetting($theme['id'], 'product_4_price', '18.900'); ?> TL</p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>" class="product-btn">Detayları Gör</a>
                </div>
            </div>
            
            <!-- Product 5 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'product_5_image')) ?: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500'; ?>" alt="Yolluk">
                </div>
                <div class="product-content">
                    <p class="product-category">Yolluklar</p>
                    <h3 class="product-title">Koridor Yolluk</h3>
                    <p class="product-description">Koridorlar için özel ölçülerde üretilmiş, kaymaz tabanlı yolluk.</p>
                    <p class="product-price"><?php echo getThemeSetting($theme['id'], 'product_5_price', '1.200'); ?> TL</p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>" class="product-btn">Detayları Gör</a>
                </div>
            </div>
            
            <!-- Product 6 -->
            <div class="product-card">
                <div class="product-image">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'product_6_image')) ?: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500'; ?>" alt="Patchwork">
                    <span class="product-badge">Yeni</span>
                </div>
                <div class="product-content">
                    <p class="product-category">Patchwork</p>
                    <h3 class="product-title">Vintage Patchwork</h3>
                    <p class="product-description">Eski halı parçalarından özel olarak tasarlanmış patchwork halı.</p>
                    <p class="product-price"><?php echo getThemeSetting($theme['id'], 'product_6_price', '6.500'); ?> TL</p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'shop_link', '#'); ?>" class="product-btn">Detayları Gör</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features">
    <div class="container">
        <div class="section-header" style="color: white;">
            <h6 style="color: var(--accent);">Neden Biz?</h6>
            <h2 style="color: white;"><?php echo getThemeSetting($theme['id'], 'features_title', 'Farkımızı Keşfedin'); ?></h2>
        </div>
        
        <div class="features-grid">
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-hand-sparkles"></i>
                </div>
                <h3>El İşçiliği</h3>
                <p>Geleneksel el dokuma teknikleriyle üretilmiş, her biri eşsiz sanat eseri halılar.</p>
            </div>
            
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-gem"></i>
                </div>
                <h3>Premium Kalite</h3>
                <p>Doğal ipek, yün ve pamuk iplikleri kullanılarak üretilmiş uzun ömürlü halılar.</p>
            </div>
            
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-truck"></i>
                </div>
                <h3>Ücretsiz Kargo</h3>
                <p>Türkiye'nin her yerine ücretsiz ve sigortalı teslimat hizmeti.</p>
            </div>
            
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3>Garanti</h3>
                <p>Tüm ürünlerimizde 5 yıl garanti ve memnuniyet garantisi.</p>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="cta-content">
        <h2><?php echo getThemeSetting($theme['id'], 'cta_title', 'Özel Sipariş için Bize Ulaşın'); ?></h2>
        <p><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'İstediğiniz ölçü, renk ve desende özel halı üretimi yapıyoruz.'); ?></p>
        <a href="<?php echo APP_URL; ?>/themes/<?php echo $theme['folder']; ?>/contact.php" class="btn btn-primary" style="background: var(--primary-dark); color: var(--accent);">
            <i class="fas fa-envelope"></i> Teklif Alın
        </a>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
