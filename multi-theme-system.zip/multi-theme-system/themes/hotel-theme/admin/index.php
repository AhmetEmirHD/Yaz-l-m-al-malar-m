<?php
/**
 * Hotel Theme Admin Panel
 */

session_start();
require_once __DIR__ . '/../../../includes/functions.php';

requireAdminLogin();

$theme = getThemeByFolder('hotel-theme');
$db = getDB();

$success = '';
$error = '';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle image uploads
    $imageFields = ['hero_bg', 'logo', 'about_image', 'gallery_1', 'gallery_2', 'gallery_3', 'gallery_4', 'gallery_5', 'gallery_6'];
    foreach ($imageFields as $field) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
            $uploadedImage = uploadImage($_FILES[$field], 'hotel');
            if ($uploadedImage) {
                setThemeSetting($theme['id'], $field, $uploadedImage);
            }
        }
    }
    
    // Handle color settings
    $colorSettings = [
        'primary_color' => sanitize($_POST['primary_color'] ?? '#c9a962'),
        'secondary_color' => sanitize($_POST['secondary_color'] ?? '#1a1a2e'),
        'accent_color' => sanitize($_POST['accent_color'] ?? '#e94560')
    ];
    
    foreach ($colorSettings as $key => $value) {
        setThemeSetting($theme['id'], $key, $value);
    }
    
    // Handle text settings based on page
    $page = $_POST['current_page'] ?? 'home';
    
    if ($page === 'settings') {
        $textSettings = [
            'site_name' => sanitize($_POST['site_name'] ?? 'Grand Luxury Hotel'),
            'brand_name' => sanitize($_POST['brand_name'] ?? 'Grand Hotel'),
            'footer_text' => sanitize($_POST['footer_text'] ?? 'Lüks ve konforun buluşma noktası.'),
            'phone' => sanitize($_POST['phone'] ?? '0212 555 55 55'),
            'email' => sanitize($_POST['email'] ?? 'info@grandhotel.com'),
            'address' => sanitize($_POST['address'] ?? 'İstanbul, Türkiye'),
            'booking_link' => sanitize($_POST['booking_link'] ?? '#')
        ];
    } elseif ($page === 'home') {
        $textSettings = [
            'hero_title' => sanitize($_POST['hero_title'] ?? 'Hayallerinizdeki'),
            'hero_title_span' => sanitize($_POST['hero_title_span'] ?? 'Tatil'),
            'hero_subtitle' => sanitize($_POST['hero_subtitle'] ?? 'Eşsiz manzara, lüks konaklama ve unutulmaz bir deneyim sizi bekliyor.'),
            'features_title' => sanitize($_POST['features_title'] ?? 'Neden Bizi Seçmelisiniz?'),
            'features_subtitle' => sanitize($_POST['features_subtitle'] ?? 'Mükemmel hizmet anlayışımız ve eşsiz olanaklarımızla ayrıcalıklı bir deneyim sunuyoruz.'),
            'gallery_title' => sanitize($_POST['gallery_title'] ?? 'Otelimizden Kareler'),
            'cta_title' => sanitize($_POST['cta_title'] ?? 'Hayalinizdeki Tatili Planlayın'),
            'cta_subtitle' => sanitize($_POST['cta_subtitle'] ?? 'Özel indirimler ve paketler için hemen rezervasyon yapın.')
        ];
    } elseif ($page === 'about') {
        $textSettings = [
            'about_title' => sanitize($_POST['about_title'] ?? 'Lüksün ve Konforun'),
            'about_title_span' => sanitize($_POST['about_title_span'] ?? 'Bulunduğu Yer'),
            'about_text_1' => sanitize($_POST['about_text_1'] ?? '2004 yılından bu yana misafirlerimize eşsiz bir konaklama deneyimi sunuyoruz.'),
            'about_text_2' => sanitize($_POST['about_text_2'] ?? '150 süit odamız, ödüllü restoranımız, lüks spa merkezimiz ve profesyonel ekibimizle hizmetinizdeyiz.'),
            'about_text_3' => sanitize($_POST['about_text_3'] ?? 'Misyonumuz, her misafirimize unutulmaz anlar yaşatmak ve kendilerini evlerinde hissedecekleri sıcak bir ortam sunmaktır.')
        ];
    } elseif ($page === 'contact') {
        $textSettings = [
            'contact_title' => sanitize($_POST['contact_title'] ?? 'Bize Ulaşın'),
            'contact_subtitle' => sanitize($_POST['contact_subtitle'] ?? 'Bizimle iletişime geçin, size yardımcı olmaktan mutluluk duyarız')
        ];
    }
    
    if (isset($textSettings)) {
        foreach ($textSettings as $key => $value) {
            setThemeSetting($theme['id'], $key, $value);
        }
    }
    
    $success = 'Ayarlar başarıyla güncellendi.';
}

$page = $_GET['page'] ?? 'home';
$pageTitles = [
    'home' => 'Ana Sayfa Ayarları',
    'about' => 'Hakkımızda Ayarları',
    'contact' => 'İletişim Ayarları',
    'settings' => 'Site Ayarları'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tema Admin | <?php echo $theme['name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Montserrat:wght@300;400;500;600&display=swap');
        
        body { 
            background: #f8f9fa; 
            font-family: 'Montserrat', sans-serif;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            padding: 1rem 1.5rem;
            display: block;
            margin: 0.25rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background: rgba(201, 169, 98, 0.2);
            color: #c9a962;
        }
        
        .sidebar a i { 
            margin-right: 0.75rem; 
            width: 20px;
            color: #c9a962;
        }
        
        .card {
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            border: none;
        }
        
        .card-header {
            background: linear-gradient(135deg, #c9a962 0%, #d4af37 100%);
            color: #1a1a2e;
            border-radius: 20px 20px 0 0 !important;
            padding: 1.5rem;
        }
        
        .card-header h5 {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            font-size: 1.3rem;
        }
        
        .form-label {
            font-weight: 600;
            color: #1a1a2e;
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-control-color {
            border-radius: 12px;
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
        }
        
        .form-control:focus {
            border-color: #c9a962;
            box-shadow: 0 0 0 0.2rem rgba(201, 169, 98, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #c9a962 0%, #d4af37 100%);
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #d4af37 0%, #c9a962 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(201, 169, 98, 0.4);
        }
        
        .image-preview {
            max-width: 150px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .section-divider {
            border-top: 2px solid #e9ecef;
            margin: 2rem 0;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar">
                <div class="text-center mb-5">
                    <i class="fas fa-hotel fa-3x mb-3" style="color: #c9a962;"></i>
                    <h5 class="text-white" style="font-family: 'Playfair Display', serif;"><?php echo $theme['name']; ?></h5>
                    <small class="text-white-50">v<?php echo $theme['version']; ?></small>
                </div>
                
                <a href="index.php?page=home" class="<?php echo $page === 'home' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Ana Sayfa
                </a>
                <a href="index.php?page=about" class="<?php echo $page === 'about' ? 'active' : ''; ?>">
                    <i class="fas fa-info-circle"></i> Hakkımızda
                </a>
                <a href="index.php?page=contact" class="<?php echo $page === 'contact' ? 'active' : ''; ?>">
                    <i class="fas fa-envelope"></i> İletişim
                </a>
                <a href="index.php?page=settings" class="<?php echo $page === 'settings' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> Site Ayarları
                </a>
                
                <div class="mt-5">
                    <a href="<?php echo APP_URL; ?>/admin/dashboard.php">
                        <i class="fas fa-arrow-left"></i> Ana Admin
                    </a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 style="font-family: 'Playfair Display', serif; font-weight: 700; color: #1a1a2e;">
                        <?php echo $pageTitles[$page] ?? 'Tema Ayarları'; ?>
                    </h2>
                    <a href="<?php echo APP_URL; ?>" target="_blank" class="btn btn-outline-primary" style="border-color: #c9a962; color: #c9a962;">
                        <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                    </a>
                </div>
                
                <?php if ($success): ?>
                    <div class="alert alert-success" style="border-radius: 12px;">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <!-- HOME PAGE SETTINGS -->
                <?php if ($page === 'home'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-home"></i> Ana Sayfa İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="home">
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-image"></i> Hero Bölümü
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Hero Arkaplanı</label>
                                    <input type="file" name="hero_bg" class="form-control" accept="image/*">
                                    <?php $heroBg = getThemeSetting($theme['id'], 'hero_bg'); ?>
                                    <?php if ($heroBg): ?>
                                        <img src="<?php echo getImageUrl($heroBg); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Ana Başlık</label>
                                    <input type="text" name="hero_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title', 'Hayallerinizdeki'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Renkli Span</label>
                                    <input type="text" name="hero_title_span" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title_span', 'Tatil'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="hero_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Eşsiz manzara, lüks konaklama ve unutulmaz bir deneyim sizi bekliyor.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-star"></i> Özellikler Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Bölüm Başlığı</label>
                                <input type="text" name="features_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'features_title', 'Neden Bizi Seçmelisiniz?'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="features_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'features_subtitle', 'Mükemmel hizmet anlayışımız ve eşsiz olanaklarımızla ayrıcalıklı bir deneyim sunuyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-images"></i> Galeri Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Galeri Başlığı</label>
                                <input type="text" name="gallery_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'gallery_title', 'Otelimizden Kareler'); ?>">
                            </div>
                            
                            <div class="row">
                                <?php for ($i = 1; $i <= 6; $i++): ?>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Görsel <?php echo $i; ?></label>
                                    <input type="file" name="gallery_<?php echo $i; ?>" class="form-control" accept="image/*">
                                    <?php $galleryImg = getThemeSetting($theme['id'], 'gallery_' . $i); ?>
                                    <?php if ($galleryImg): ?>
                                        <img src="<?php echo getImageUrl($galleryImg); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <?php endfor; ?>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-bullhorn"></i> CTA Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'cta_title', 'Hayalinizdeki Tatili Planlayın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'Özel indirimler ve paketler için hemen rezervasyon yapın.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- ABOUT PAGE SETTINGS -->
                <?php elseif ($page === 'about'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-info-circle"></i> Hakkımızda İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="about">
                            
                            <div class="mb-3">
                                <label class="form-label">Hakkımızda Görseli</label>
                                <input type="file" name="about_image" class="form-control" accept="image/*">
                                <?php $aboutImg = getThemeSetting($theme['id'], 'about_image'); ?>
                                <?php if ($aboutImg): ?>
                                    <img src="<?php echo getImageUrl($aboutImg); ?>" class="image-preview mt-2">
                                <?php endif; ?>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Ana Başlık</label>
                                    <input type="text" name="about_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_title', 'Lüksün ve Konforun'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Renkli Span</label>
                                    <input type="text" name="about_title_span" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_title_span', 'Bulunduğu Yer'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 1</label>
                                <textarea name="about_text_1" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'about_text_1', '2004 yılından bu yana misafirlerimize eşsiz bir konaklama deneyimi sunuyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 2</label>
                                <textarea name="about_text_2" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'about_text_2', '150 süit odamız, ödüllü restoranımız, lüks spa merkezimiz ve profesyonel ekibimizle hizmetinizdeyiz.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 3</label>
                                <textarea name="about_text_3" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'about_text_3', 'Misyonumuz, her misafirimize unutulmaz anlar yaşatmak ve kendilerini evlerinde hissedecekleri sıcak bir ortam sunmaktır.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- CONTACT PAGE SETTINGS -->
                <?php elseif ($page === 'contact'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-envelope"></i> İletişim İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="">
                            <input type="hidden" name="current_page" value="contact">
                            
                            <div class="mb-3">
                                <label class="form-label">Sayfa Başlığı</label>
                                <input type="text" name="contact_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'contact_title', 'Bize Ulaşın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Sayfa Alt Başlığı</label>
                                <input type="text" name="contact_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'contact_subtitle', 'Bizimle iletişime geçin, size yardımcı olmaktan mutluluk duyarız'); ?>">
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- SITE SETTINGS -->
                <?php elseif ($page === 'settings'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-cog"></i> Genel Site Ayarları</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="settings">
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-palette"></i> Renk Ayarları
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Ana Renk (Altın)</label>
                                    <input type="color" name="primary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'primary_color', '#c9a962'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">İkincil Renk (Koyu)</label>
                                    <input type="color" name="secondary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'secondary_color', '#1a1a2e'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Vurgu Rengi (Aksan)</label>
                                    <input type="color" name="accent_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'accent_color', '#e94560'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-image"></i> Logo ve Favicon
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Logo</label>
                                <input type="file" name="logo" class="form-control" accept="image/*">
                                <?php $logo = getThemeSetting($theme['id'], 'logo'); ?>
                                <?php if ($logo): ?>
                                    <img src="<?php echo getImageUrl($logo); ?>" class="image-preview mt-2">
                                <?php endif; ?>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-info-circle"></i> Site Bilgileri
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Site Adı</label>
                                    <input type="text" name="site_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'site_name', 'Grand Luxury Hotel'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Marka Adı</label>
                                    <input type="text" name="brand_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'brand_name', 'Grand Hotel'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Footer Metni</label>
                                <textarea name="footer_text" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'footer_text', 'Lüks ve konforun buluşma noktası. Unutulmaz bir konaklama deneyimi için bizi tercih edin.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-address-card"></i> İletişim Bilgileri
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Telefon</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'phone', '0212 555 55 55'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">E-posta</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'email', 'info@grandhotel.com'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Adres</label>
                                <textarea name="address" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'address', 'Beşiktaş, İstanbul, Türkiye'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Rezervasyon Linki</label>
                                <input type="text" name="booking_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>">
                                <small class="text-muted">Rezervasyon butonuna tıklandığında yönlendirilecek link</small>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
