<?php
/**
 * Hotel Theme - Main Layout (Home Page)
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('hotel-theme');
$pageTitle = 'Ana Sayfa';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <div class="hero-badge">
            <i class="fas fa-star"></i> 5 Yıldızlı Lüks Otel
        </div>
        <h1>
            <?php echo getThemeSetting($theme['id'], 'hero_title', 'Hayallerinizdeki'); ?>
            <span><?php echo getThemeSetting($theme['id'], 'hero_title_span', 'Tatil'); ?></span>
        </h1>
        <p><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Eşsiz manzara, lüks konaklama ve unutulmaz bir deneyim sizi bekliyor.'); ?></p>
        <div class="hero-buttons">
            <a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn btn-primary">
                <i class="fas fa-calendar-check"></i> Rezervasyon Yap
            </a>
            <a href="#features" class="btn btn-outline">
                <i class="fas fa-play"></i> Keşfet
            </a>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features" id="features">
    <div class="container">
        <div class="section-header">
            <h6>Lüks Konaklama</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'features_title', 'Neden Bizi Seçmelisiniz?'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'features_subtitle', 'Mükemmel hizmet anlayışımız ve eşsiz olanaklarımızla ayrıcalıklı bir deneyim sunuyoruz.'); ?></p>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-bed"></i>
                </div>
                <h3>Lüks Odalar</h3>
                <p>Kraliçe boyutunda yataklar, özel balkonlar ve panoramik manzaralarla donatılmış süit odalarımızda konforu hissedin.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-utensils"></i>
                </div>
                <h3>Gurme Restoran</h3>
                <p>Ödüllü şeflerimiz tarafından hazırlanan dünya mutfağından lezzetler ve geniş şarap menümüz sizi bekliyor.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-spa"></i>
                </div>
                <h3>Spa & Wellness</h3>
                <p>Profesyonel terapistler eşliğinde masaj terapileri, sauna ve jakuzi ile kendinizi şımartın.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-swimming-pool"></i>
                </div>
                <h3>Havuz</h3>
                <p>Deniz manzaralı sonsuzluk havuzu ve havuz barı ile serinlemenin en lüks yolu.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-dumbbell"></i>
                </div>
                <h3>Fitness Merkezi</h3>
                <p>En son teknoloji ekipmanlarla donatılmış 7/24 açık spor salonumuzda formunuzu koruyun.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-wifi"></i>
                </div>
                <h3>Yüksek Hızlı WiFi</h3>
                <p>Tesis genelinde ücretsiz yüksek hızlı internet erişimi ile bağlantınızı kesmeyin.</p>
            </div>
        </div>
    </div>
</section>

<!-- Gallery Section -->
<section class="gallery">
    <div class="container">
        <div class="section-header" style="color: white;">
            <h6 style="color: var(--primary);">Galeri</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'gallery_title', 'Otelimizden Kareler'); ?></h2>
            <p style="color: rgba(255,255,255,0.8);">Lüks yaşamın en güzel anları</p>
        </div>
        
        <div class="gallery-grid">
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_1')) ?: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600'; ?>" alt="Otel Görünümü">
                <div class="gallery-overlay">
                    <h4>Lobi</h4>
                    <p>Şık karşılama alanı</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_2')) ?: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=600'; ?>" alt="Oda">
                <div class="gallery-overlay">
                    <h4>Deluxe Oda</h4>
                    <p>Konforlu konaklama</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_3')) ?: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=600'; ?>" alt="Havuz">
                <div class="gallery-overlay">
                    <h4>Sonsuzluk Havuzu</h4>
                    <p>Muhteşem manzara</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_4')) ?: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=600'; ?>" alt="Restoran">
                <div class="gallery-overlay">
                    <h4>Restoran</h4>
                    <p>Gurme lezzetler</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_5')) ?: 'https://images.unsplash.com/photo-1540541338287-41700207dee6?w=600'; ?>" alt="Spa">
                <div class="gallery-overlay">
                    <h4>Spa</h4>
                    <p>Rahatlama alanı</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_6')) ?: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=600'; ?>" alt="Sahil">
                <div class="gallery-overlay">
                    <h4>Plaj</h4>
                    <p>Özel kumsal</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="cta-content">
        <h2><?php echo getThemeSetting($theme['id'], 'cta_title', 'Hayalinizdeki Tatili Planlayın'); ?></h2>
        <p><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'Özel indirimler ve paketler için hemen rezervasyon yapın.'); ?></p>
        <a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn btn-primary" style="background: var(--secondary); color: var(--white);">
            <i class="fas fa-calendar-alt"></i> Hemen Rezervasyon Yap
        </a>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
