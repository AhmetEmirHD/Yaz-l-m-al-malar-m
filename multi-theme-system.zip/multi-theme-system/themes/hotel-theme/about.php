<?php
/**
 * Hotel Theme - About Page
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('hotel-theme');
$pageTitle = 'Hakkımızda';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Page Hero -->
<section class="page-hero">
    <div class="page-hero-content">
        <h1>Hakkımızda</h1>
        <p>Lüks ve zarafetin 20 yıllık mirası</p>
    </div>
</section>

<!-- About Section -->
<section class="about-section">
    <div class="container">
        <div class="about-content">
            <div class="about-image">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'about_image')) ?: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800'; ?>" alt="Otel Hakkında">
            </div>
            <div class="about-text">
                <h2>
                    <?php echo getThemeSetting($theme['id'], 'about_title', 'Lüksün ve Konforun'); ?>
                    <span><?php echo getThemeSetting($theme['id'], 'about_title_span', 'Bulunduğu Yer'); ?></span>
                </h2>
                <p><?php echo getThemeSetting($theme['id'], 'about_text_1', '2004 yılından bu yana misafirlerimize eşsiz bir konaklama deneyimi sunuyoruz. Boğaz\'ın eşsiz manzarası eşliğinde, dünya standartlarında hizmet anlayışımızla ayrıcalıklı bir tatil vadediyoruz.'); ?></p>
                <p><?php echo getThemeSetting($theme['id'], 'about_text_2', '150 süit odamız, ödüllü restoranımız, lüks spa merkezimiz ve profesyonel ekibimizle siz değerli misafirlerimizi ağırlamaktan gurur duyuyoruz.'); ?></p>
                <p><?php echo getThemeSetting($theme['id'], 'about_text_3', 'Misyonumuz, her misafirimize unutulmaz anlar yaşatmak ve kendilerini evlerinde hissedecekleri sıcak bir ortam sunmaktır.'); ?></p>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="features" style="background: linear-gradient(135deg, var(--secondary) 0%, var(--dark) 100%); color: white;">
    <div class="container">
        <div class="section-header" style="color: white;">
            <h6 style="color: var(--primary);">Rakamlarla Biz</h6>
            <h2 style="color: white;">Başarılarımız</h2>
        </div>
        
        <div class="features-grid" style="grid-template-columns: repeat(4, 1fr);">
            <div class="feature-card" style="text-align: center; background: rgba(255,255,255,0.05);">
                <div class="feature-icon" style="margin: 0 auto 1.5rem;">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <h3 style="font-size: 3rem; margin-bottom: 0.5rem;">20+</h3>
                <p>Yıllık Deneyim</p>
            </div>
            
            <div class="feature-card" style="text-align: center; background: rgba(255,255,255,0.05);">
                <div class="feature-icon" style="margin: 0 auto 1.5rem;">
                    <i class="fas fa-bed"></i>
                </div>
                <h3 style="font-size: 3rem; margin-bottom: 0.5rem;">150</h3>
                <p>Lüks Oda</p>
            </div>
            
            <div class="feature-card" style="text-align: center; background: rgba(255,255,255,0.05);">
                <div class="feature-icon" style="margin: 0 auto 1.5rem;">
                    <i class="fas fa-users"></i>
                </div>
                <h3 style="font-size: 3rem; margin-bottom: 0.5rem;">50K+</h3>
                <p>Mutlu Misafir</p>
            </div>
            
            <div class="feature-card" style="text-align: center; background: rgba(255,255,255,0.05);">
                <div class="feature-icon" style="margin: 0 auto 1.5rem;">
                    <i class="fas fa-award"></i>
                </div>
                <h3 style="font-size: 3rem; margin-bottom: 0.5rem;">25</h3>
                <p>Ödül</p>
            </div>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
