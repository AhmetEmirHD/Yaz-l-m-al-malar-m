    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <h3><i class="fas fa-hotel"></i> <?php echo getThemeSetting($theme['id'], 'brand_name', 'Grand Hotel'); ?></h3>
                    <p><?php echo getThemeSetting($theme['id'], 'footer_text', 'Lüks ve konforun buluşma noktası. Unutulmaz bir konaklama deneyimi için bizi tercih edin.'); ?></p>
                    <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                        <a href="#" style="color: var(--primary); font-size: 1.5rem;"><i class="fab fa-facebook"></i></a>
                        <a href="#" style="color: var(--primary); font-size: 1.5rem;"><i class="fab fa-instagram"></i></a>
                        <a href="#" style="color: var(--primary); font-size: 1.5rem;"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                <div class="footer-contact">
                    <h4>İletişim</h4>
                    <p><i class="fas fa-map-marker-alt" style="color: var(--primary); margin-right: 0.5rem;"></i> <?php echo getThemeSetting($theme['id'], 'address', 'İstanbul, Türkiye'); ?></p>
                    <p><i class="fas fa-phone" style="color: var(--primary); margin-right: 0.5rem;"></i> <?php echo getThemeSetting($theme['id'], 'phone', '0212 555 55 55'); ?></p>
                    <p><i class="fas fa-envelope" style="color: var(--primary); margin-right: 0.5rem;"></i> <?php echo getThemeSetting($theme['id'], 'email', 'info@grandhotel.com'); ?></p>
                </div>
                <div class="footer-hours">
                    <h4>Çalışma Saatleri</h4>
                    <p>Resepsiyon: 7/24</p>
                    <p>Restoran: 06:00 - 23:00</p>
                    <p>Spa: 09:00 - 21:00</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo getThemeSetting($theme['id'], 'brand_name', 'Grand Hotel'); ?>. Tüm hakları saklıdır.</p>
            </div>
        </div>
    </footer>
</body>
</html>
