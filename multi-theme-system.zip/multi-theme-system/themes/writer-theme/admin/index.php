<?php
/**
 * Writer Theme Admin Panel
 */

session_start();
require_once __DIR__ . '/../../../includes/functions.php';

requireAdminLogin();

$theme = getThemeByFolder('writer-theme');
$db = getDB();

$success = '';
$error = '';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = [
        'site_name' => sanitize($_POST['site_name'] ?? 'Profesyonel Yazım Hizmetleri'),
        'brand_name' => sanitize($_POST['brand_name'] ?? 'WriterPro'),
        'email' => sanitize($_POST['email'] ?? 'info@writerpro.com'),
        'phone' => sanitize($_POST['phone'] ?? '0555 987 65 43'),
        'hero_title' => sanitize($_POST['hero_title'] ?? 'Profesyonel Yazım Hizmetleri'),
        'hero_subtitle' => sanitize($_POST['hero_subtitle'] ?? 'Makale, blog, SEO ve akademik yazılar için uzman editör desteği.'),
        'cta_title' => sanitize($_POST['cta_title'] ?? 'Projenizi Başlatın'),
        'cta_subtitle' => sanitize($_POST['cta_subtitle'] ?? 'Profesyonel yazım hizmetleri için hemen iletişime geçin.')
    ];
    
    foreach ($settings as $key => $value) {
        setThemeSetting($theme['id'], $key, $value);
    }
    
    $success = 'Ayarlar başarıyla güncellendi.';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tema Admin | <?php echo $theme['name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 0.75rem 1.5rem;
            display: block;
            margin: 0.25rem 0;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.2);
        }
        .sidebar a i { margin-right: 0.75rem; width: 20px; }
        .card {
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            border: none;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-pen-fancy fa-3x mb-2 text-white"></i>
                    <h5 class="text-white"><?php echo $theme['name']; ?></h5>
                    <small class="text-white-50">v<?php echo $theme['version']; ?></small>
                </div>
                <a href="index.php" class="active">
                    <i class="fas fa-cog"></i> Ayarlar
                </a>
                <a href="<?php echo APP_URL; ?>/admin/dashboard.php">
                    <i class="fas fa-arrow-left"></i> Ana Admin
                </a>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Tema Ayarları</h2>
                    <a href="<?php echo APP_URL; ?>" target="_blank" class="btn btn-outline-primary">
                        <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                    </a>
                </div>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-sliders-h"></i> Genel Ayarlar</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Site Adı</label>
                                    <input type="text" name="site_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'site_name', 'Profesyonel Yazım Hizmetleri'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Marka Adı</label>
                                    <input type="text" name="brand_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'brand_name', 'WriterPro'); ?>">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">E-posta</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'email', 'info@writerpro.com'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Telefon</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'phone', '0555 987 65 43'); ?>">
                                </div>
                            </div>
                            
                            <hr>
                            
                            <h6 class="mb-3">Hero Bölümü</h6>
                            <div class="mb-3">
                                <label class="form-label">Ana Başlık</label>
                                <input type="text" name="hero_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title', 'Profesyonel Yazım Hizmetleri'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="hero_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Makale, blog, SEO ve akademik yazılar için uzman editör desteği.'); ?></textarea>
                            </div>
                            
                            <hr>
                            
                            <h6 class="mb-3">CTA Bölümü</h6>
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'cta_title', 'Projenizi Başlatın'); ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'Profesyonel yazım hizmetleri için hemen iletişime geçin.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
