<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' : ''; ?><?php echo getThemeSetting($theme['id'], 'site_name', 'Profesyonel Yazım Hizmetleri'); ?></title>
    <link rel="stylesheet" href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container">
            <a href="/multi-theme-system" class="navbar-brand">
                <i class="fas fa-pen-fancy"></i> <?php echo getThemeSetting($theme['id'], 'brand_name', 'WriterPro'); ?>
            </a>
            <ul class="navbar-nav">
                <li><a href="/multi-theme-system">Ana Sayfa</a></li>
                <li><a href="#services">Hizmetler</a></li>
                <li><a href="#portfolio">Portfolyo</a></li>
                <li><a href="#contact">İletişim</a></li>
            </ul>
        </div>
    </nav>
