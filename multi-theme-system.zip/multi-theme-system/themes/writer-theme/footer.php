    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo getThemeSetting($theme['id'], 'brand_name', 'WriterPro'); ?>. Tüm hakları saklıdır.</p>
            <p>
                <i class="fas fa-envelope"></i> <?php echo getThemeSetting($theme['id'], 'email', 'info@writerpro.com'); ?> | 
                <i class="fas fa-phone"></i> <?php echo getThemeSetting($theme['id'], 'phone', '0555 987 65 43'); ?>
            </p>
        </div>
    </footer>
</body>
</html>
