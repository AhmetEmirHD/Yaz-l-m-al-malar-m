<?php
/**
 * Writer Theme Layout
 */

// Get theme info
$theme = getThemeByFolder('writer-theme');
$pageTitle = isset($pageTitle) ? $pageTitle : 'Ana Sayfa';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <h1><?php echo getThemeSetting($theme['id'], 'hero_title', 'Profesyonel Yazım Hizmetleri'); ?></h1>
        <p><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Makale, blog, SEO ve akademik yazılar için uzman editör desteği.'); ?></p>
        <a href="#contact" class="btn btn-white">
            <i class="fas fa-envelope"></i> İletişime Geç
        </a>
    </div>
</section>

<!-- Services Section -->
<section class="services" id="services">
    <div class="container">
        <div class="section-title">
            <h2>Hizmetlerimiz</h2>
            <p>Profesyonel yazım ve editörlük hizmetleri ile içeriklerinizi zenginleştirin</p>
        </div>
        
        <div class="services-grid">
            <div class="service-card">
                <i class="fas fa-newspaper"></i>
                <h3>Makale Yazımı</h3>
                <p>SEO uyumlu, özgün ve ilgi çekici makaleler. Her konuda uzman yazar kadromuzla yanınızdayız.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-blog"></i>
                <h3>Blog İçerikleri</h3>
                <p>Markanız için etkileyici blog yazıları. Okuyucularınızı bağlayan, paylaşılabilir içerikler.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-search"></i>
                <h3>SEO Yazıları</h3>
                <p>Google'da üst sıralarda yer almanızı sağlayan SEO uyumlu içerikler. Anahtar kelime analizi dahil.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-share-alt"></i>
                <h3>Sosyal Medya</h3>
                <p>Instagram, Facebook, Twitter ve LinkedIn için etkili sosyal medya içerikleri.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-graduation-cap"></i>
                <h3>Akademik Yazılar</h3>
                <p>Tez, makale ve akademik çalışmalar için profesyonel editörlük ve yazım desteği.</p>
            </div>
            
            <div class="service-card">
                <i class="fas fa-edit"></i>
                <h3>Editörlük</h3>
                <p>Mevcut metinlerinizi düzeltme, düzenleme ve geliştirme hizmetleri. Dilbilgisi ve akış kontrolü.</p>
            </div>
        </div>
    </div>
</section>

<!-- Portfolio Section -->
<section class="portfolio" id="portfolio">
    <div class="container">
        <div class="section-title">
            <h2>Portfolyo</h2>
            <p>Başarıyla tamamladığımız projelerden örnekler</p>
        </div>
        
        <div class="portfolio-grid">
            <div class="portfolio-item">
                <img src="https://images.unsplash.com/photo-1455390582262-044cdead277a?w=400" alt="Proje 1">
                <div class="portfolio-item-content">
                    <h4>Teknoloji Blogu</h4>
                    <p>50+ SEO uyumlu makale</p>
                </div>
            </div>
            
            <div class="portfolio-item">
                <img src="https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=400" alt="Proje 2">
                <div class="portfolio-item-content">
                    <h4>E-Ticaret İçerikleri</h4>
                    <p>Ürün açıklamaları ve blog</p>
                </div>
            </div>
            
            <div class="portfolio-item">
                <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400" alt="Proje 3">
                <div class="portfolio-item-content">
                    <h4>Akademik Tez</h4>
                    <p>Editörlük ve formatlama</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta" id="contact">
    <div class="container">
        <h2><?php echo getThemeSetting($theme['id'], 'cta_title', 'Projenizi Başlatın'); ?></h2>
        <p><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'Profesyonel yazım hizmetleri için hemen iletişime geçin.'); ?></p>
        <a href="mailto:<?php echo getThemeSetting($theme['id'], 'email', 'info@writerpro.com'); ?>" class="btn btn-white">
            <i class="fas fa-envelope"></i> <?php echo getThemeSetting($theme['id'], 'email', 'info@writerpro.com'); ?>
        </a>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
