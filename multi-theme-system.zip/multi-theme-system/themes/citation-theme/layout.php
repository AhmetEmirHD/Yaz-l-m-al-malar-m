<?php
/**
 * Citation Theme - Main Layout (Home Page)
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('citation-theme');
$pageTitle = 'Ana Sayfa';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>
                <?php echo getThemeSetting($theme['id'], 'hero_title', 'Akademik Kaynakçılık'); ?>
                <span><?php echo getThemeSetting($theme['id'], 'hero_title_span', 'Kolaylaştı'); ?></span>
            </h1>
            <p><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'APA, MLA, Chicago ve daha fazla kaynak stili ile akademik çalışmalarınızı profesyonel bir şekilde tamamlayın.'); ?></p>
            <div class="hero-buttons">
                <a href="<?php echo getThemeSetting($theme['id'], 'cta_link', '#'); ?>" class="btn btn-primary">
                    <i class="fas fa-rocket"></i> Ücretsiz Dene
                </a>
                <a href="#how-it-works" class="btn btn-outline-white">
                    <i class="fas fa-play-circle"></i> Nasıl Çalışır
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features">
    <div class="container">
        <div class="section-header">
            <h6>Neden Bizi Seçmelisiniz?</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'features_title', 'Profesyonel Özellikler'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'features_subtitle', 'Akademik çalışmalarınızı kolaylaştıran gelişmiş özelliklerimizle tanışın.'); ?></p>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-bolt"></i>
                </div>
                <h3>Hızlı Oluşturma</h3>
                <p>Saniyeler içinde profesyonel kaynakça oluşturun. Otomatik formatlama ile zaman kazanın.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-book"></i>
                </div>
                <h3>Çoklu Stil Desteği</h3>
                <p>APA, MLA, Chicago, Harvard, IEEE ve daha fazla kaynak stilini destekler.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3>Otomatik Doğrulama</h3>
                <p>Kaynaklarınızı otomatik olarak doğrular ve eksik bilgileri uyarır.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-cloud"></i>
                </div>
                <h3>Bulut Depolama</h3>
                <p>Tüm kaynaklarınızı bulutta güvenli bir şekilde saklayın ve her yerden erişin.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-share-alt"></i>
                </div>
                <h3>Kolay Paylaşım</h3>
                <p>Kaynakçalarınızı tek tıkla arkadaşlarınızla veya işbirlikçilerinizle paylaşın.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-language"></i>
                </div>
                <h3>Çoklu Dil Desteği</h3>
                <p>Türkçe, İngilizce ve daha fazla dilde kaynakça oluşturma desteği.</p>
            </div>
        </div>
    </div>
</section>

<!-- Citation Styles Section -->
<section class="citation-styles" id="styles">
    <div class="container">
        <div class="section-header">
            <h6>Kaynak Stilleri</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'styles_title', 'Desteklenen Stiller'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'styles_subtitle', 'En popüler akademik kaynak stillerini destekliyoruz.'); ?></p>
        </div>
        
        <div class="styles-grid">
            <div class="style-card">
                <div class="style-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <h3>APA Style</h3>
                <p>American Psychological Association formatı. Psikoloji, eğitim ve sosyal bilimler için.</p>
                <div class="style-examples">
                    <code>Smith, J. (2020). Book Title. Publisher.</code>
                </div>
            </div>
            
            <div class="style-card">
                <div class="style-icon">
                    <i class="fas fa-university"></i>
                </div>
                <h3>MLA Style</h3>
                <p>Modern Language Association formatı. Edebiyat, dil ve beşeri bilimler için.</p>
                <div class="style-examples">
                    <code>Smith, John. Book Title. Publisher, 2020.</code>
                </div>
            </div>
            
            <div class="style-card">
                <div class="style-icon">
                    <i class="fas fa-building"></i>
                </div>
                <h3>Chicago Style</h3>
                <p>Chicago Manual of Style formatı. Tarih, işletme ve güzel sanatlar için.</p>
                <div class="style-examples">
                    <code>Smith, John. Book Title. City: Publisher, 2020.</code>
                </div>
            </div>
            
            <div class="style-card">
                <div class="style-icon">
                    <i class="fas fa-school"></i>
                </div>
                <h3>Harvard Style</h3>
                <p>Harvard referencing formatı. Geniş kullanım alanına sahip akademik stil.</p>
                <div class="style-examples">
                    <code>Smith, J. (2020) 'Book Title', Publisher.</code>
                </div>
            </div>
            
            <div class="style-card">
                <div class="style-icon">
                    <i class="fas fa-microchip"></i>
                </div>
                <h3>IEEE Style</h3>
                <p>Institute of Electrical and Electronics Engineers formatı. Mühendislik ve teknik alanlar için.</p>
                <div class="style-examples">
                    <code>[1] J. Smith, "Book Title," Publisher, 2020.</code>
                </div>
            </div>
            
            <div class="style-card">
                <div class="style-icon">
                    <i class="fas fa-plus-circle"></i>
                </div>
                <h3>Diğer Stiller</h3>
                <p>Vancouver, AMA, ACS ve daha fazla kaynak stilini destekliyoruz.</p>
                <div class="style-examples">
                    <code>Özelleştirilmiş format seçenekleri</code>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="how-it-works" id="how-it-works">
    <div class="container">
        <div class="section-header">
            <h6>Nasıl Çalışır</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'how_title', '3 Basit Adım'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'how_subtitle', 'Sadece 3 adımda profesyonel kaynakçalar oluşturun.'); ?></p>
        </div>
        
        <div class="steps-container">
            <div class="step">
                <div class="step-number">1</div>
                <div class="step-content">
                    <h3>Kaynak Ekle</h3>
                    <p>Kaynak bilgilerini girin veya ISBN/DOI ile otomatik olarak çekin. Kitap, makale, web sitesi ve daha fazla kaynak türünü destekler.</p>
                </div>
            </div>
            
            <div class="step">
                <div class="step-number">2</div>
                <div class="step-content">
                    <h3>Stil Seç</h3>
                    <p>APA, MLA, Chicago veya başka bir kaynak stili seçin. Otomatik formatlama ile kaynaklarınız seçtiğiniz stile göre düzenlenir.</p>
                </div>
            </div>
            
            <div class="step">
                <div class="step-number">3</div>
                <div class="step-content">
                    <h3>Dışa Aktar</h3>
                    <p>Kaynakçanızı Word, PDF, RTF veya diğer formatlarda dışa aktarın. Doğrudan belgenize yapıştırın veya indirin.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="testimonials">
    <div class="container">
        <div class="section-header">
            <h6>Kullanıcı Yorumları</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'testimonials_title', 'Ne Diyorlar?'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'testimonials_subtitle', 'Akademisyenler ve öğrencilerden geri bildirimler.'); ?></p>
        </div>
        
        <div class="testimonials-grid">
            <div class="testimonial-card">
                <p class="testimonial-text"><?php echo getThemeSetting($theme['id'], 'testimonial_1', 'Tez çalışmam için bu platformu kullandım ve inanılmaz zaman kazandım. APA formatı mükemmel çıktı.'); ?></p>
                <div class="testimonial-author">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'avatar_1')) ?: 'https://randomuser.me/api/portraits/women/45.jpg'; ?>" alt="Dr. Ayşe K." class="testimonial-avatar">
                    <div class="testimonial-info">
                        <h4>Dr. Ayşe Kaya</h4>
                        <p>Doçent, İstanbul Üniversitesi</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <p class="testimonial-text"><?php echo getThemeSetting($theme['id'], 'testimonial_2', 'Öğrencilerime kaynakça oluşturma ödevlerinde bu platformu tavsiye ediyorum. Çok kullanışlı ve profesyonel.'); ?></p>
                <div class="testimonial-author">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'avatar_2')) ?: 'https://randomuser.me/api/portraits/men/32.jpg'; ?>" alt="Prof. Mehmet D." class="testimonial-avatar">
                    <div class="testimonial-info">
                        <h4>Prof. Mehmet Demir</h4>
                        <p>Profesör, Boğaziçi Üniversitesi</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <p class="testimonial-text"><?php echo getThemeSetting($theme['id'], 'testimonial_3', 'Lisans tezimde kullandım, çok memnun kaldım. Ücretsiz versiyonu bile mükemmel özelliklere sahip.'); ?></p>
                <div class="testimonial-author">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'avatar_3')) ?: 'https://randomuser.me/api/portraits/women/68.jpg'; ?>" alt="Zeynep Y." class="testimonial-avatar">
                    <div class="testimonial-info">
                        <h4>Zeynep Yılmaz</h4>
                        <p>Lisans Öğrencisi</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="container">
        <div class="cta-content">
            <h2><?php echo getThemeSetting($theme['id'], 'cta_title', 'Hemen Başlayın'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'Ücretsiz hesap oluşturun ve akademik çalışmalarınızı profesyonel bir şekilde tamamlayın.'); ?></p>
            <a href="<?php echo getThemeSetting($theme['id'], 'cta_link', '#'); ?>" class="btn btn-lg">
                <i class="fas fa-user-plus"></i> Ücretsiz Kayıt Ol
            </a>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
