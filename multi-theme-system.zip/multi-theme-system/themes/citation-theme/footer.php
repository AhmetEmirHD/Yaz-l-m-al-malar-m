<!-- Footer -->
<footer>
    <div class="container">
        <div class="footer-content">
            <!-- Brand Section -->
            <div>
                <a href="/multi-theme-system" class="footer-brand">
                    <i class="fas fa-quote-right"></i> <?php echo getThemeSetting($theme['id'], 'brand_name', 'CitationPro'); ?>
                </a>
                <p>
                    <?php echo getThemeSetting($theme['id'], 'footer_description', 'Akademik ve profesyonel kaynakçılık çözümleri. APA, MLA, Chicago ve daha fazlası için güvenilir platformunuz.'); ?>
                </p>
                <div style="margin-top: 20px;">
                    <a href="<?php echo getThemeSetting($theme['id'], 'facebook_link', '#'); ?>" style="color: var(--secondary); margin-right: 15px; font-size: 1.2rem;"><i class="fab fa-facebook-f"></i></a>
                    <a href="<?php echo getThemeSetting($theme['id'], 'twitter_link', '#'); ?>" style="color: var(--secondary); margin-right: 15px; font-size: 1.2rem;"><i class="fab fa-twitter"></i></a>
                    <a href="<?php echo getThemeSetting($theme['id'], 'linkedin_link', '#'); ?>" style="color: var(--secondary); margin-right: 15px; font-size: 1.2rem;"><i class="fab fa-linkedin-in"></i></a>
                    <a href="<?php echo getThemeSetting($theme['id'], 'instagram_link', '#'); ?>" style="color: var(--secondary); font-size: 1.2rem;"><i class="fab fa-instagram"></i></a>
                </div>
            </div>

            <!-- Quick Links -->
            <div>
                <h4>Hızlı Bağlantılar</h4>
                <div class="footer-links">
                    <a href="/multi-theme-system">Ana Sayfa</a>
                    <a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/about.php">Hakkımızda</a>
                    <a href="#styles">Kaynak Stilleri</a>
                    <a href="#how-it-works">Nasıl Çalışır</a>
                    <a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/contact.php">İletişim</a>
                </div>
            </div>

            <!-- Citation Styles -->
            <div>
                <h4>Kaynak Stilleri</h4>
                <div class="footer-links">
                    <a href="#styles">APA Style</a>
                    <a href="#styles">MLA Style</a>
                    <a href="#styles">Chicago Style</a>
                    <a href="#styles">Harvard Style</a>
                    <a href="#styles">IEEE Style</a>
                </div>
            </div>

            <!-- Contact -->
            <div>
                <h4>İletişim</h4>
                <ul class="footer-contact">
                    <li>
                        <i class="fas fa-envelope"></i>
                        <span><?php echo getThemeSetting($theme['id'], 'email', 'info@citationpro.com'); ?></span>
                    </li>
                    <li>
                        <i class="fas fa-phone"></i>
                        <span><?php echo getThemeSetting($theme['id'], 'phone', '+90 212 555 5555'); ?></span>
                    </li>
                    <li>
                        <i class="fas fa-map-marker-alt"></i>
                        <span><?php echo getThemeSetting($theme['id'], 'address', 'İstanbul, Türkiye'); ?></span>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php echo getThemeSetting($theme['id'], 'brand_name', 'CitationPro'); ?>. Tüm hakları saklıdır.</p>
        </div>
    </div>
</footer>

<script>
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Add scroll animation for elements
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.feature-card, .style-card, .testimonial-card').forEach(el => {
        observer.observe(el);
    });
</script>
