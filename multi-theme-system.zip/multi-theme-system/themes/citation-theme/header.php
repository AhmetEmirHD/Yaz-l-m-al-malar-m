<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' : ''; ?><?php echo getThemeSetting($theme['id'], 'site_name', 'CitationPro'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Georgia:wght@400;500;600;700&family=Segoe+UI:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: <?php echo getThemeSetting($theme['id'], 'primary_color', '#2c3e50'); ?>;
            --primary-light: <?php echo getThemeSetting($theme['id'], 'primary_color', '#34495e'); ?>;
            --primary-dark: <?php echo getThemeSetting($theme['id'], 'primary_color', '#1a252f'); ?>;
            --secondary: <?php echo getThemeSetting($theme['id'], 'secondary_color', '#3498db'); ?>;
            --secondary-light: <?php echo getThemeSetting($theme['id'], 'secondary_color', '#5dade2'); ?>;
            --secondary-dark: <?php echo getThemeSetting($theme['id'], 'secondary_color', '#2980b9'); ?>;
            --accent: <?php echo getThemeSetting($theme['id'], 'accent_color', '#e74c3c'); ?>;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar" id="navbar">
        <div class="container">
            <a href="/multi-theme-system" class="navbar-brand">
                <i class="fas fa-quote-right"></i>
                <span><?php echo getThemeSetting($theme['id'], 'brand_name', 'CitationPro'); ?></span>
            </a>
            <ul class="navbar-nav">
                <li><a href="/multi-theme-system" class="active">Ana Sayfa</a></li>
                <li><a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/about.php">Hakkımızda</a></li>
                <li><a href="#styles">Kaynak Stilleri</a></li>
                <li><a href="#how-it-works">Nasıl Çalışır</a></li>
                <li><a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/contact.php">İletişim</a></li>
                <li><a href="<?php echo getThemeSetting($theme['id'], 'cta_link', '#'); ?>" class="btn btn-primary btn-sm" style="color: white;">Ücretsiz Dene</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    </script>
