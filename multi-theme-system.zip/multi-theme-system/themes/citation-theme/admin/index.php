<?php
/**
 * Citation Theme Admin Panel
 */

session_start();
require_once __DIR__ . '/../../../includes/functions.php';

requireAdminLogin();

$theme = getThemeByFolder('citation-theme');
$db = getDB();

$success = '';
$error = '';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle image uploads
    $imageFields = ['about_image', 'avatar_1', 'avatar_2', 'avatar_3'];
    foreach ($imageFields as $field) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
            $uploadedImage = uploadImage($_FILES[$field], 'citation');
            if ($uploadedImage) {
                setThemeSetting($theme['id'], $field, $uploadedImage);
            }
        }
    }
    
    // Handle color settings
    $colorSettings = [
        'primary_color' => sanitize($_POST['primary_color'] ?? '#2c3e50'),
        'secondary_color' => sanitize($_POST['secondary_color'] ?? '#3498db'),
        'accent_color' => sanitize($_POST['accent_color'] ?? '#e74c3c')
    ];
    
    foreach ($colorSettings as $key => $value) {
        setThemeSetting($theme['id'], $key, $value);
    }
    
    // Handle text settings based on page
    $page = $_POST['current_page'] ?? 'home';
    
    if ($page === 'settings') {
        $textSettings = [
            'site_name' => sanitize($_POST['site_name'] ?? 'CitationPro'),
            'brand_name' => sanitize($_POST['brand_name'] ?? 'CitationPro'),
            'footer_description' => sanitize($_POST['footer_description'] ?? 'Akademik ve profesyonel kaynakçılık çözümleri.'),
            'phone' => sanitize($_POST['phone'] ?? '+90 212 555 5555'),
            'email' => sanitize($_POST['email'] ?? 'info@citationpro.com'),
            'address' => sanitize($_POST['address'] ?? 'İstanbul, Türkiye'),
            'cta_link' => sanitize($_POST['cta_link'] ?? '#'),
            'facebook_link' => sanitize($_POST['facebook_link'] ?? '#'),
            'twitter_link' => sanitize($_POST['twitter_link'] ?? '#'),
            'linkedin_link' => sanitize($_POST['linkedin_link'] ?? '#'),
            'instagram_link' => sanitize($_POST['instagram_link'] ?? '#')
        ];
    } elseif ($page === 'home') {
        $textSettings = [
            'hero_title' => sanitize($_POST['hero_title'] ?? 'Akademik Kaynakçılık'),
            'hero_title_span' => sanitize($_POST['hero_title_span'] ?? 'Kolaylaştı'),
            'hero_subtitle' => sanitize($_POST['hero_subtitle'] ?? 'APA, MLA, Chicago ve daha fazla kaynak stili ile akademik çalışmalarınızı profesyonel bir şekilde tamamlayın.'),
            'features_title' => sanitize($_POST['features_title'] ?? 'Profesyonel Özellikler'),
            'features_subtitle' => sanitize($_POST['features_subtitle'] ?? 'Akademik çalışmalarınızı kolaylaştıran gelişmiş özelliklerimizle tanışın.'),
            'styles_title' => sanitize($_POST['styles_title'] ?? 'Desteklenen Stiller'),
            'styles_subtitle' => sanitize($_POST['styles_subtitle'] ?? 'En popüler akademik kaynak stillerini destekliyoruz.'),
            'how_title' => sanitize($_POST['how_title'] ?? '3 Basit Adım'),
            'how_subtitle' => sanitize($_POST['how_subtitle'] ?? 'Sadece 3 adımda profesyonel kaynakçalar oluşturun.'),
            'testimonials_title' => sanitize($_POST['testimonials_title'] ?? 'Ne Diyorlar?'),
            'testimonials_subtitle' => sanitize($_POST['testimonials_subtitle'] ?? 'Akademisyenler ve öğrencilerden geri bildirimler.'),
            'testimonial_1' => sanitize($_POST['testimonial_1'] ?? 'Tez çalışmam için bu platformu kullandım ve inanılmaz zaman kazandım.'),
            'testimonial_2' => sanitize($_POST['testimonial_2'] ?? 'Öğrencilerime kaynakça oluşturma ödevlerinde bu platformu tavsiye ediyorum.'),
            'testimonial_3' => sanitize($_POST['testimonial_3'] ?? 'Lisans tezimde kullandım, çok memnun kaldım.'),
            'cta_title' => sanitize($_POST['cta_title'] ?? 'Hemen Başlayın'),
            'cta_subtitle' => sanitize($_POST['cta_subtitle'] ?? 'Ücretsiz hesap oluşturun ve akademik çalışmalarınızı profesyonel bir şekilde tamamlayın.')
        ];
    } elseif ($page === 'about') {
        $textSettings = [
            'about_title' => sanitize($_POST['about_title'] ?? 'Hakkımızda'),
            'about_subtitle' => sanitize($_POST['about_subtitle'] ?? 'Akademik dünyasını desteklemek için buradayız.'),
            'story_title' => sanitize($_POST['story_title'] ?? 'Akademik Mükemmellik'),
            'story_text_1' => sanitize($_POST['story_text_1'] ?? '2018 yılında akademisyenler ve öğrencilerin kaynakça oluşturma sürecini kolaylaştırmak için yola çıktık.'),
            'story_text_2' => sanitize($_POST['story_text_2'] ?? 'Bugün dünya genelinde yüz binlerce kullanıcıya hizmet veriyoruz.'),
            'story_text_3' => sanitize($_POST['story_text_3'] ?? 'Misyonumuz, akademik bütünlüğü korumak ve araştırmacıların çalışmalarını kolaylaştırmaktır.'),
            'values_title' => sanitize($_POST['values_title'] ?? 'Bizi Ayıran Özellikler'),
            'team_title' => sanitize($_POST['team_title'] ?? 'Profesyonel Ekip'),
            'team_subtitle' => sanitize($_POST['team_subtitle'] ?? 'Deneyimli akademisyenler ve teknoloji uzmanları.'),
            'team_1_name' => sanitize($_POST['team_1_name'] ?? 'Dr. Ahmet Yılmaz'),
            'team_1_role' => sanitize($_POST['team_1_role'] ?? 'Kurucu & CEO'),
            'team_1_desc' => sanitize($_POST['team_1_desc'] ?? 'Eski akademisyen ve teknoloji girişimcisi.'),
            'team_2_name' => sanitize($_POST['team_2_name'] ?? 'Dr. Ayşe Demir'),
            'team_2_role' => sanitize($_POST['team_2_role'] ?? 'Akademik Danışman'),
            'team_2_desc' => sanitize($_POST['team_2_desc'] ?? 'Bibliyografi ve akademik yazım uzmanı.'),
            'team_3_name' => sanitize($_POST['team_3_name'] ?? 'Mehmet Kaya'),
            'team_3_role' => sanitize($_POST['team_3_role'] ?? 'CTO'),
            'team_3_desc' => sanitize($_POST['team_3_desc'] ?? '10 yıllık deneyimli yazılım mimarı.'),
            'about_cta_title' => sanitize($_POST['about_cta_title'] ?? 'Ekibimize Katılın'),
            'about_cta_subtitle' => sanitize($_POST['about_cta_subtitle'] ?? 'Açık pozisyonlarımızı keşfedin ve büyüyen ekibimizin bir parçası olun.')
        ];
    } elseif ($page === 'contact') {
        $textSettings = [
            'contact_title' => sanitize($_POST['contact_title'] ?? 'İletişim'),
            'contact_subtitle' => sanitize($_POST['contact_subtitle'] ?? 'Bizimle iletişime geçin, size yardımcı olalım.'),
            'contact_section_title' => sanitize($_POST['contact_section_title'] ?? 'İletişim Bilgileri'),
            'contact_cta_title' => sanitize($_POST['contact_cta_title'] ?? 'Hemen Başlayın'),
            'contact_cta_subtitle' => sanitize($_POST['contact_cta_subtitle'] ?? 'Ücretsiz hesap oluşturun ve akademik çalışmalarınızı profesyonel bir şekilde tamamlayın.')
        ];
    }
    
    if (isset($textSettings)) {
        foreach ($textSettings as $key => $value) {
            setThemeSetting($theme['id'], $key, $value);
        }
    }
    
    $success = 'Ayarlar başarıyla güncellendi.';
}

$page = $_GET['page'] ?? 'home';
$pageTitles = [
    'home' => 'Ana Sayfa Ayarları',
    'about' => 'Hakkımızda Ayarları',
    'contact' => 'İletişim Ayarları',
    'settings' => 'Site Ayarları'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tema Admin | <?php echo $theme['name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia:wght@400;500;600;700&family=Segoe+UI:wght@300;400;500;600&display=swap');
        
        body { 
            background: #f8f9fa; 
            font-family: 'Segoe UI', sans-serif;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #2c3e50 0%, #1a252f 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            padding: 1rem 1.5rem;
            display: block;
            margin: 0.25rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background: rgba(52, 152, 219, 0.2);
            color: #3498db;
        }
        
        .sidebar a i { 
            margin-right: 0.75rem; 
            width: 20px;
            color: #3498db;
        }
        
        .card {
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            border: none;
        }
        
        .card-header {
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
            color: #ffffff;
            border-radius: 20px 20px 0 0 !important;
            padding: 1.5rem;
        }
        
        .card-header h5 {
            font-family: 'Georgia', serif;
            font-weight: 700;
            font-size: 1.3rem;
        }
        
        .form-label {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-control-color {
            border-radius: 12px;
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
        }
        
        .form-control:focus {
            border-color: #3498db;
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            color: #ffffff;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #2980b9 0%, #3498db 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(52, 152, 219, 0.4);
        }
        
        .image-preview {
            max-width: 150px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .section-divider {
            border-top: 2px solid #e9ecef;
            margin: 2rem 0;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar">
                <div class="text-center mb-5">
                    <i class="fas fa-quote-right fa-3x mb-3" style="color: #3498db;"></i>
                    <h5 class="text-white" style="font-family: 'Georgia', serif;"><?php echo $theme['name']; ?></h5>
                    <small class="text-white-50">v<?php echo $theme['version']; ?></small>
                </div>
                
                <a href="index.php?page=home" class="<?php echo $page === 'home' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Ana Sayfa
                </a>
                <a href="index.php?page=about" class="<?php echo $page === 'about' ? 'active' : ''; ?>">
                    <i class="fas fa-info-circle"></i> Hakkımızda
                </a>
                <a href="index.php?page=contact" class="<?php echo $page === 'contact' ? 'active' : ''; ?>">
                    <i class="fas fa-envelope"></i> İletişim
                </a>
                <a href="index.php?page=settings" class="<?php echo $page === 'settings' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> Site Ayarları
                </a>
                
                <div class="mt-5">
                    <a href="<?php echo APP_URL; ?>/admin/dashboard.php">
                        <i class="fas fa-arrow-left"></i> Ana Admin
                    </a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 style="font-family: 'Georgia', serif; font-weight: 700; color: #2c3e50;">
                        <?php echo $pageTitles[$page] ?? 'Tema Ayarları'; ?>
                    </h2>
                    <a href="<?php echo APP_URL; ?>" target="_blank" class="btn btn-outline-primary" style="border-color: #3498db; color: #3498db;">
                        <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                    </a>
                </div>
                
                <?php if ($success): ?>
                    <div class="alert alert-success" style="border-radius: 12px;">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <!-- HOME PAGE SETTINGS -->
                <?php if ($page === 'home'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-home"></i> Ana Sayfa İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="home">
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-image"></i> Hero Bölümü
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Ana Başlık</label>
                                    <input type="text" name="hero_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title', 'Akademik Kaynakçılık'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Renkli Span</label>
                                    <input type="text" name="hero_title_span" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title_span', 'Kolaylaştı'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="hero_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'APA, MLA, Chicago ve daha fazla kaynak stili ile akademik çalışmalarınızı profesyonel bir şekilde tamamlayın.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-star"></i> Özellikler Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Bölüm Başlığı</label>
                                <input type="text" name="features_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'features_title', 'Profesyonel Özellikler'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="features_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'features_subtitle', 'Akademik çalışmalarınızı kolaylaştıran gelişmiş özelliklerimizle tanışın.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-book"></i> Kaynak Stilleri Bölümü
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Bölüm Başlığı</label>
                                    <input type="text" name="styles_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'styles_title', 'Desteklenen Stiller'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="styles_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'styles_subtitle', 'En popüler akademik kaynak stillerini destekliyoruz.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-cogs"></i> Nasıl Çalışır Bölümü
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Bölüm Başlığı</label>
                                    <input type="text" name="how_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'how_title', '3 Basit Adım'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="how_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'how_subtitle', 'Sadece 3 adımda profesyonel kaynakçalar oluşturun.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-comments"></i> Müşteri Yorumları
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Bölüm Başlığı</label>
                                    <input type="text" name="testimonials_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'testimonials_title', 'Ne Diyorlar?'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="testimonials_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'testimonials_subtitle', 'Akademisyenler ve öğrencilerden geri bildirimler.'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Yorum 1</label>
                                <textarea name="testimonial_1" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'testimonial_1', 'Tez çalışmam için bu platformu kullandım ve inanılmaz zaman kazandım.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Yorum 2</label>
                                <textarea name="testimonial_2" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'testimonial_2', 'Öğrencilerime kaynakça oluşturma ödevlerinde bu platformu tavsiye ediyorum.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Yorum 3</label>
                                <textarea name="testimonial_3" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'testimonial_3', 'Lisans tezimde kullandım, çok memnun kaldım.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-bullhorn"></i> CTA Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'cta_title', 'Hemen Başlayın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'Ücretsiz hesap oluşturun ve akademik çalışmalarınızı profesyonel bir şekilde tamamlayın.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- ABOUT PAGE SETTINGS -->
                <?php elseif ($page === 'about'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-info-circle"></i> Hakkımızda İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="about">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Sayfa Başlığı</label>
                                    <input type="text" name="about_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_title', 'Hakkımızda'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="about_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_subtitle', 'Akademik dünyasını desteklemek için buradayız.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-history"></i> Hikayemiz
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Görsel</label>
                                <input type="file" name="about_image" class="form-control" accept="image/*">
                                <?php $aboutImg = getThemeSetting($theme['id'], 'about_image'); ?>
                                <?php if ($aboutImg): ?>
                                    <img src="<?php echo getImageUrl($aboutImg); ?>" class="image-preview mt-2">
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Bölüm Başlığı</label>
                                <input type="text" name="story_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'story_title', 'Akademik Mükemmellik'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 1</label>
                                <textarea name="story_text_1" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'story_text_1', '2018 yılında akademisyenler ve öğrencilerin kaynakça oluşturma sürecini kolaylaştırmak için yola çıktık.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 2</label>
                                <textarea name="story_text_2" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'story_text_2', 'Bugün dünya genelinde yüz binlerce kullanıcıya hizmet veriyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 3</label>
                                <textarea name="story_text_3" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'story_text_3', 'Misyonumuz, akademik bütünlüğü korumak ve araştırmacıların çalışmalarını kolaylaştırmaktır.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-heart"></i> Değerlerimiz Başlığı
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Başlık</label>
                                <input type="text" name="values_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'values_title', 'Bizi Ayıran Özellikler'); ?>">
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-users"></i> Ekibimiz
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Bölüm Başlığı</label>
                                    <input type="text" name="team_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_title', 'Profesyonel Ekip'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="team_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_subtitle', 'Deneyimli akademisyenler ve teknoloji uzmanları.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-user"></i> Ekip Üyesi 1
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="avatar_1" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'avatar_1'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">İsim</label>
                                    <input type="text" name="team_1_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_1_name', 'Dr. Ahmet Yılmaz'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Unvan</label>
                                    <input type="text" name="team_1_role" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_1_role', 'Kurucu & CEO'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Açıklama</label>
                                    <input type="text" name="team_1_desc" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_1_desc', 'Eski akademisyen ve teknoloji girişimcisi.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-user"></i> Ekip Üyesi 2
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="avatar_2" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'avatar_2'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">İsim</label>
                                    <input type="text" name="team_2_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_2_name', 'Dr. Ayşe Demir'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Unvan</label>
                                    <input type="text" name="team_2_role" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_2_role', 'Akademik Danışman'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Açıklama</label>
                                    <input type="text" name="team_2_desc" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_2_desc', 'Bibliyografi ve akademik yazım uzmanı.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-user"></i> Ekip Üyesi 3
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="avatar_3" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'avatar_3'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">İsim</label>
                                    <input type="text" name="team_3_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_3_name', 'Mehmet Kaya'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Unvan</label>
                                    <input type="text" name="team_3_role" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_3_role', 'CTO'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Açıklama</label>
                                    <input type="text" name="team_3_desc" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_3_desc', '10 yıllık deneyimli yazılım mimarı.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-bullhorn"></i> CTA Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="about_cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_cta_title', 'Ekibimize Katılın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="about_cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'about_cta_subtitle', 'Açık pozisyonlarımızı keşfedin ve büyüyen ekibimizin bir parçası olun.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- CONTACT PAGE SETTINGS -->
                <?php elseif ($page === 'contact'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-envelope"></i> İletişim İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="">
                            <input type="hidden" name="current_page" value="contact">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Sayfa Başlığı</label>
                                    <input type="text" name="contact_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'contact_title', 'İletişim'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Sayfa Alt Başlığı</label>
                                    <input type="text" name="contact_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'contact_subtitle', 'Bizimle iletişime geçin, size yardımcı olalım.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-bullhorn"></i> CTA Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="contact_cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'contact_cta_title', 'Hemen Başlayın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="contact_cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'contact_cta_subtitle', 'Ücretsiz hesap oluşturun ve akademik çalışmalarınızı profesyonel bir şekilde tamamlayın.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- SITE SETTINGS -->
                <?php elseif ($page === 'settings'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-cog"></i> Genel Site Ayarları</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="settings">
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-palette"></i> Renk Ayarları
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Ana Renk</label>
                                    <input type="color" name="primary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'primary_color', '#2c3e50'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">İkincil Renk</label>
                                    <input type="color" name="secondary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'secondary_color', '#3498db'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Vurgu Rengi</label>
                                    <input type="color" name="accent_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'accent_color', '#e74c3c'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-info-circle"></i> Site Bilgileri
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Site Adı</label>
                                    <input type="text" name="site_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'site_name', 'CitationPro'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Marka Adı</label>
                                    <input type="text" name="brand_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'brand_name', 'CitationPro'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Footer Açıklaması</label>
                                <textarea name="footer_description" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'footer_description', 'Akademik ve profesyonel kaynakçılık çözümleri.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-address-card"></i> İletişim Bilgileri
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Telefon</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'phone', '+90 212 555 5555'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">E-posta</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'email', 'info@citationpro.com'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Adres</label>
                                <textarea name="address" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'address', 'İstanbul, Türkiye'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #3498db; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-link"></i> Linkler
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Linki</label>
                                <input type="text" name="cta_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'cta_link', '#'); ?>">
                                <small class="text-muted">CTA butonuna tıklandığında yönlendirilecek link</small>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Facebook Linki</label>
                                    <input type="text" name="facebook_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'facebook_link', '#'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Twitter Linki</label>
                                    <input type="text" name="twitter_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'twitter_link', '#'); ?>">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">LinkedIn Linki</label>
                                    <input type="text" name="linkedin_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'linkedin_link', '#'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Instagram Linki</label>
                                    <input type="text" name="instagram_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'instagram_link', '#'); ?>">
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
