<?php
/**
 * Citation Theme - About Page
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('citation-theme');
$pageTitle = 'Hakkımızda';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- About Hero Section -->
<section class="hero" style="height: 60vh; min-height: 400px;">
    <div class="container">
        <div class="hero-content">
            <h1><?php echo getThemeSetting($theme['id'], 'about_title', 'Hakkımızda'); ?></h1>
            <p><?php echo getThemeSetting($theme['id'], 'about_subtitle', 'Akademik dünyasını desteklemek için buradayız.'); ?></p>
        </div>
    </div>
</section>

<!-- About Content Section -->
<section class="features">
    <div class="container">
        <div class="section-header">
            <h6>Hikayemiz</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'story_title', 'Akademik Mükemmellik'); ?></h2>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 50px; align-items: center;">
            <div>
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'about_image')) ?: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600'; ?>" alt="Ekibimiz" style="border-radius: var(--radius-lg); box-shadow: var(--shadow-xl);">
            </div>
            <div>
                <p style="font-size: 1.1rem; line-height: 1.8; margin-bottom: 20px;">
                    <?php echo getThemeSetting($theme['id'], 'story_text_1', '2018 yılında akademisyenler ve öğrencilerin kaynakça oluşturma sürecini kolaylaştırmak için yola çıktık.'); ?>
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8; margin-bottom: 20px;">
                    <?php echo getThemeSetting($theme['id'], 'story_text_2', 'Bugün dünya genelinde yüz binlerce kullanıcıya hizmet veriyoruz ve her geçen gün daha fazla akademisyenin çalışmalarını destekliyoruz.'); ?>
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8;">
                    <?php echo getThemeSetting($theme['id'], 'story_text_3', 'Misyonumuz, akademik bütünlüğü korumak ve araştırmacıların çalışmalarını kolaylaştırmaktır.'); ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Values Section -->
<section class="citation-styles">
    <div class="container">
        <div class="section-header">
            <h6>Değerlerimiz</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'values_title', 'Bizi Ayıran Özellikler'); ?></h2>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-award"></i>
                </div>
                <h3>Kalite</h3>
                <p>En yüksek akademik standartlara uygun kaynakçalar sunuyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3>Güven</h3>
                <p>Kullanıcı verilerini güvenli bir şekilde koruyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-lightbulb"></i>
                </div>
                <h3>Yenilikçilik</h3>
                <p>Sürekli yeni özellikler ve kaynak stilleri ekliyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h3>Kullanıcı Odaklı</h3>
                <p>Kullanıcı geri bildirimlerine dayalı olarak gelişiyoruz.</p>
            </div>
        </div>
    </div>
</section>

<!-- Team Section -->
<section class="features">
    <div class="container">
        <div class="section-header">
            <h6>Ekibimiz</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'team_title', 'Profesyonel Ekip'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'team_subtitle', 'Deneyimli akademisyenler ve teknoloji uzmanları.'); ?></p>
        </div>
        
        <div class="styles-grid">
            <div class="style-card" style="text-align: center;">
                <div class="style-icon" style="margin: 0 auto 25px;">
                    <i class="fas fa-user-tie"></i>
                </div>
                <h3><?php echo getThemeSetting($theme['id'], 'team_1_name', 'Dr. Ahmet Yılmaz'); ?></h3>
                <p style="color: var(--secondary); font-weight: 600;"><?php echo getThemeSetting($theme['id'], 'team_1_role', 'Kurucu & CEO'); ?></p>
                <p><?php echo getThemeSetting($theme['id'], 'team_1_desc', 'Eski akademisyen ve teknoloji girişimcisi.'); ?></p>
            </div>
            
            <div class="style-card" style="text-align: center;">
                <div class="style-icon" style="margin: 0 auto 25px;">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <h3><?php echo getThemeSetting($theme['id'], 'team_2_name', 'Dr. Ayşe Demir'); ?></h3>
                <p style="color: var(--secondary); font-weight: 600;"><?php echo getThemeSetting($theme['id'], 'team_2_role', 'Akademik Danışman'); ?></p>
                <p><?php echo getThemeSetting($theme['id'], 'team_2_desc', 'Bibliyografi ve akademik yazım uzmanı.'); ?></p>
            </div>
            
            <div class="style-card" style="text-align: center;">
                <div class="style-icon" style="margin: 0 auto 25px;">
                    <i class="fas fa-code"></i>
                </div>
                <h3><?php echo getThemeSetting($theme['id'], 'team_3_name', 'Mehmet Kaya'); ?></h3>
                <p style="color: var(--secondary); font-weight: 600;"><?php echo getThemeSetting($theme['id'], 'team_3_role', 'CTO'); ?></p>
                <p><?php echo getThemeSetting($theme['id'], 'team_3_desc', '10 yıllık deneyimli yazılım mimarı.'); ?></p>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="container">
        <div class="cta-content">
            <h2><?php echo getThemeSetting($theme['id'], 'about_cta_title', 'Ekibimize Katılın'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'about_cta_subtitle', 'Açık pozisyonlarımızı keşfedin ve büyüyen ekibimizin bir parçası olun.'); ?></p>
            <a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/contact.php" class="btn btn-lg">
                <i class="fas fa-envelope"></i> İletişime Geçin
            </a>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
