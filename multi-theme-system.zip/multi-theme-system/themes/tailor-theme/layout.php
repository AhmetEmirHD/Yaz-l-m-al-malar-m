<?php
/**
 * Tailor Theme - Main Layout (Home Page)
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('tailor-theme');
$pageTitle = 'Ana Sayfa';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <div class="hero-badge">
                <i class="fas fa-star"></i> 30 Yıllık Tecrübe
            </div>
            <h1>
                <?php echo getThemeSetting($theme['id'], 'hero_title', 'Size Özel'); ?>
                <span><?php echo getThemeSetting($theme['id'], 'hero_title_span', 'Dikiş Hizmetleri'); ?></span>
            </h1>
            <p><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Ustalık ve kalitenin buluştuğu noktada, size özel dikiş çözümleri sunuyoruz.'); ?></p>
            <div class="hero-buttons">
                <a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn btn-primary">
                    <i class="fas fa-calendar-alt"></i> Randevu Al
                </a>
                <a href="#services" class="btn btn-outline-white">
                    <i class="fas fa-eye"></i> Hizmetleri İncele
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features">
    <div class="container">
        <div class="section-header">
            <h6>Neden Bizi Seçmelisiniz?</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'features_title', 'Kalite ve Güven'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'features_subtitle', 'Yılların deneyimi ve profesyonel ekibimizle size en iyi hizmeti sunuyoruz.'); ?></p>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-cut"></i>
                </div>
                <h3>Profesyonel Dikiş</h3>
                <p>Ustalarımızın elinden çıkan her dikiş, mükemmel işçilik ve titizlikle hazırlanır.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-ruler-combined"></i>
                </div>
                <h3>Özel Ölçü</h3>
                <p>Vücut ölçülerinize tam uyumlu kıyafetler için özel ölçü alma hizmetimiz mevcuttur.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-tshirt"></i>
                </div>
                <h3>Kaliteli Kumaş</h3>
                <p>En kaliteli kumaşları seçerek, uzun ömürlü ve şık kıyafetler dikiyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3>Zamanında Teslim</h3>
                <p>Taahhüt ettiğimiz süre içinde, işinizi zamanında ve eksiksiz teslim ediyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <h3>Tamir Hizmeti</h3>
                <p>Kıyafetlerinizin tamiri ve değişikliği için profesyonel hizmet sunuyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <h3>Uygun Fiyat</h3>
                <p>Kaliteyi uygun fiyatlarla sunarak, her bütçeye hitap ediyoruz.</p>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="services" id="services">
    <div class="container">
        <div class="section-header">
            <h6>Hizmetlerimiz</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'services_title', 'Size Özel Hizmetler'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'services_subtitle', 'İhtiyaçlarınıza uygun profesyonel dikiş hizmetleri sunuyoruz.'); ?></p>
        </div>
        
        <div class="services-grid">
            <div class="service-card">
                <div class="service-image" style="background-image: url('<?php echo getImageUrl(getThemeSetting($theme['id'], 'service_1_image')) ?: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600'; ?>');">
                </div>
                <div class="service-content">
                    <span class="service-price"><?php echo getThemeSetting($theme['id'], 'service_1_price', '₺500\'den başlayan'); ?></span>
                    <h3><?php echo getThemeSetting($theme['id'], 'service_1_title', 'Takım Elbise Dikimi'); ?></h3>
                    <p><?php echo getThemeSetting($theme['id'], 'service_1_desc', 'Özel ölçüde, size uygun takım elbise dikimi. Kumaş seçimi dahil.'); ?></p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn btn-primary" style="margin-top: 15px;">Randevu Al</a>
                </div>
            </div>
            
            <div class="service-card">
                <div class="service-image" style="background-image: url('<?php echo getImageUrl(getThemeSetting($theme['id'], 'service_2_image')) ?: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600'; ?>');">
                </div>
                <div class="service-content">
                    <span class="service-price"><?php echo getThemeSetting($theme['id'], 'service_2_price', '₺200\'den başlayan'); ?></span>
                    <h3><?php echo getThemeSetting($theme['id'], 'service_2_title', 'Kıyafet Tamiri'); ?></h3>
                    <p><?php echo getThemeSetting($theme['id'], 'service_2_desc', 'Kıyafetlerinizin tamiri, boyu ayarlama ve değişiklik işlemleri.'); ?></p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn btn-primary" style="margin-top: 15px;">Randevu Al</a>
                </div>
            </div>
            
            <div class="service-card">
                <div class="service-image" style="background-image: url('<?php echo getImageUrl(getThemeSetting($theme['id'], 'service_3_image')) ?: 'https://images.unsplash.com/photo-1558171813-4c088753af8f?w=600'; ?>');">
                </div>
                <div class="service-content">
                    <span class="service-price"><?php echo getThemeSetting($theme['id'], 'service_3_price', '₺150\'den başlayan'); ?></span>
                    <h3><?php echo getThemeSetting($theme['id'], 'service_3_title', 'Özel Dikim'); ?></h3>
                    <p><?php echo getThemeSetting($theme['id'], 'service_3_desc', 'Özel tasarımlarınız için profesyonel dikim hizmeti.'); ?></p>
                    <a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn btn-primary" style="margin-top: 15px;">Randevu Al</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Gallery Section -->
<section class="gallery" id="gallery">
    <div class="container">
        <div class="section-header">
            <h6>Galeri</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'gallery_title', 'Çalışmalarımız'); ?></h2>
            <p style="color: rgba(255,255,255,0.8);">Ustalarımızın elinden çıkan örnek çalışmalar</p>
        </div>
        
        <div class="gallery-grid">
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_1')) ?: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600'; ?>" alt="Takım Elbise">
                <div class="gallery-overlay">
                    <h4>Takım Elbise</h4>
                    <p>Özel Dikim</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_2')) ?: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600'; ?>" alt="Kumaş">
                <div class="gallery-overlay">
                    <h4>Kumaş Seçimi</h4>
                    <p>Premium Kalite</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_3')) ?: 'https://images.unsplash.com/photo-1558171813-4c088753af8f?w=600'; ?>" alt="Atölye">
                <div class="gallery-overlay">
                    <h4>Atölyemiz</h4>
                    <p>Profesyonel Ortam</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_4')) ?: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600'; ?>" alt="Dikiş">
                <div class="gallery-overlay">
                    <h4>Dikiş Detayları</h4>
                    <p>İnce İşçilik</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_5')) ?: 'https://images.unsplash.com/photo-1617137968427-85924c800a22?w=600'; ?>" alt="Ölçü">
                <div class="gallery-overlay">
                    <h4>Özel Ölçü</h4>
                    <p>Tam Uyum</p>
                </div>
            </div>
            
            <div class="gallery-item">
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'gallery_6')) ?: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600'; ?>" alt="Tamamlanmış">
                <div class="gallery-overlay">
                    <h4>Tamamlanmış İşler</h4>
                    <p>Mükemmel Sonuç</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="testimonials">
    <div class="container">
        <div class="section-header">
            <h6>Müşteri Yorumları</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'testimonials_title', 'Ne Diyorlar?'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'testimonials_subtitle', 'Müşterilerimizin deneyimleri ve geri bildirimleri.'); ?></p>
        </div>
        
        <div class="testimonials-grid">
            <div class="testimonial-card">
                <p class="testimonial-text"><?php echo getThemeSetting($theme['id'], 'testimonial_1', 'Harika bir işçilik! Takım elbitem tam istediğim gibi oldu. Kesinlikle tavsiye ederim.'); ?></p>
                <div class="testimonial-author">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'avatar_1')) ?: 'https://randomuser.me/api/portraits/men/32.jpg'; ?>" alt="Ahmet Y." class="testimonial-avatar">
                    <div class="testimonial-info">
                        <h4>Ahmet Yılmaz</h4>
                        <p>İş Adamı</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <p class="testimonial-text"><?php echo getThemeSetting($theme['id'], 'testimonial_2', 'Hızlı ve kaliteli hizmet. Kıyafetlerimin tamiri için her zaman burayı tercih ediyorum.'); ?></p>
                <div class="testimonial-author">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'avatar_2')) ?: 'https://randomuser.me/api/portraits/women/44.jpg'; ?>" alt="Ayşe K." class="testimonial-avatar">
                    <div class="testimonial-info">
                        <h4>Ayşe Kaya</h4>
                        <p>Mimar</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <p class="testimonial-text"><?php echo getThemeSetting($theme['id'], 'testimonial_3', 'Profesyonel ekip ve güler yüzlü hizmet. Düğünüm için özel dikim yaptırdım, çok memnun kaldım.'); ?></p>
                <div class="testimonial-author">
                    <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'avatar_3')) ?: 'https://randomuser.me/api/portraits/men/67.jpg'; ?>" alt="Mehmet D." class="testimonial-avatar">
                    <div class="testimonial-info">
                        <h4>Mehmet Demir</h4>
                        <p>Avukat</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="container">
        <div class="cta-content">
            <h2><?php echo getThemeSetting($theme['id'], 'cta_title', 'Hayalinizdeki Kıyafet İçin Randevu Alın'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'Size özel dikiş hizmetlerimizden yararlanmak için hemen randevu alın.'); ?></p>
            <a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn">
                <i class="fas fa-calendar-alt"></i> Hemen Randevu Al
            </a>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
