<?php
/**
 * Tailor Theme Admin Panel
 */

session_start();
require_once __DIR__ . '/../../../includes/functions.php';

requireAdminLogin();

$theme = getThemeByFolder('tailor-theme');
$db = getDB();

$success = '';
$error = '';

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle image uploads
    $imageFields = ['about_image', 'service_1_image', 'service_2_image', 'service_3_image', 'gallery_1', 'gallery_2', 'gallery_3', 'gallery_4', 'gallery_5', 'gallery_6', 'team_1_image', 'team_2_image', 'team_3_image', 'avatar_1', 'avatar_2', 'avatar_3'];
    foreach ($imageFields as $field) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
            $uploadedImage = uploadImage($_FILES[$field], 'tailor');
            if ($uploadedImage) {
                setThemeSetting($theme['id'], $field, $uploadedImage);
            }
        }
    }
    
    // Handle color settings
    $colorSettings = [
        'primary_color' => sanitize($_POST['primary_color'] ?? '#c9a962'),
        'secondary_color' => sanitize($_POST['secondary_color'] ?? '#1a1a2e'),
        'accent_color' => sanitize($_POST['accent_color'] ?? '#e94560'),
        'gold_color' => sanitize($_POST['gold_color'] ?? '#d4af37'),
        'cream_color' => sanitize($_POST['cream_color'] ?? '#f5f0e1')
    ];
    
    foreach ($colorSettings as $key => $value) {
        setThemeSetting($theme['id'], $key, $value);
    }
    
    // Handle text settings based on page
    $page = $_POST['current_page'] ?? 'home';
    
    if ($page === 'settings') {
        $textSettings = [
            'site_name' => sanitize($_POST['site_name'] ?? 'Elegant Tailor'),
            'brand_name' => sanitize($_POST['brand_name'] ?? 'Elegant Tailor'),
            'footer_description' => sanitize($_POST['footer_description'] ?? 'Yılların deneyimi ve ustalığı ile size özel dikiş hizmetleri sunuyoruz.'),
            'phone' => sanitize($_POST['phone'] ?? '+90 212 555 5555'),
            'email' => sanitize($_POST['email'] ?? 'info@eleganttailor.com'),
            'address' => sanitize($_POST['address'] ?? 'İstanbul, Türkiye'),
            'working_hours' => sanitize($_POST['working_hours'] ?? 'Pzt-Cmt: 09:00 - 19:00'),
            'booking_link' => sanitize($_POST['booking_link'] ?? '#'),
            'facebook_link' => sanitize($_POST['facebook_link'] ?? '#'),
            'instagram_link' => sanitize($_POST['instagram_link'] ?? '#'),
            'twitter_link' => sanitize($_POST['twitter_link'] ?? '#'),
            'linkedin_link' => sanitize($_POST['linkedin_link'] ?? '#')
        ];
    } elseif ($page === 'home') {
        $textSettings = [
            'hero_title' => sanitize($_POST['hero_title'] ?? 'Size Özel'),
            'hero_title_span' => sanitize($_POST['hero_title_span'] ?? 'Dikiş Hizmetleri'),
            'hero_subtitle' => sanitize($_POST['hero_subtitle'] ?? 'Ustalık ve kalitenin buluştuğu noktada, size özel dikiş çözümleri sunuyoruz.'),
            'features_title' => sanitize($_POST['features_title'] ?? 'Kalite ve Güven'),
            'features_subtitle' => sanitize($_POST['features_subtitle'] ?? 'Yılların deneyimi ve profesyonel ekibimizle size en iyi hizmeti sunuyoruz.'),
            'services_title' => sanitize($_POST['services_title'] ?? 'Size Özel Hizmetler'),
            'services_subtitle' => sanitize($_POST['services_subtitle'] ?? 'İhtiyaçlarınıza uygun profesyonel dikiş hizmetleri sunuyoruz.'),
            'service_1_title' => sanitize($_POST['service_1_title'] ?? 'Takım Elbise Dikimi'),
            'service_1_desc' => sanitize($_POST['service_1_desc'] ?? 'Özel ölçüde, size uygun takım elbise dikimi. Kumaş seçimi dahil.'),
            'service_1_price' => sanitize($_POST['service_1_price'] ?? '₺500\'den başlayan'),
            'service_2_title' => sanitize($_POST['service_2_title'] ?? 'Kıyafet Tamiri'),
            'service_2_desc' => sanitize($_POST['service_2_desc'] ?? 'Kıyafetlerinizin tamiri, boyu ayarlama ve değişiklik işlemleri.'),
            'service_2_price' => sanitize($_POST['service_2_price'] ?? '₺200\'den başlayan'),
            'service_3_title' => sanitize($_POST['service_3_title'] ?? 'Özel Dikim'),
            'service_3_desc' => sanitize($_POST['service_3_desc'] ?? 'Özel tasarımlarınız için profesyonel dikim hizmeti.'),
            'service_3_price' => sanitize($_POST['service_3_price'] ?? '₺150\'den başlayan'),
            'gallery_title' => sanitize($_POST['gallery_title'] ?? 'Çalışmalarımız'),
            'testimonials_title' => sanitize($_POST['testimonials_title'] ?? 'Ne Diyorlar?'),
            'testimonials_subtitle' => sanitize($_POST['testimonials_subtitle'] ?? 'Müşterilerimizin deneyimleri ve geri bildirimleri.'),
            'testimonial_1' => sanitize($_POST['testimonial_1'] ?? 'Harika bir işçilik! Takım elbitem tam istediğim gibi oldu. Kesinlikle tavsiye ederim.'),
            'testimonial_2' => sanitize($_POST['testimonial_2'] ?? 'Hızlı ve kaliteli hizmet. Kıyafetlerimin tamiri için her zaman burayı tercih ediyorum.'),
            'testimonial_3' => sanitize($_POST['testimonial_3'] ?? 'Profesyonel ekip ve güler yüzlü hizmet. Düğünüm için özel dikim yaptırdım, çok memnun kaldım.'),
            'cta_title' => sanitize($_POST['cta_title'] ?? 'Hayalinizdeki Kıyafet İçin Randevu Alın'),
            'cta_subtitle' => sanitize($_POST['cta_subtitle'] ?? 'Size özel dikiş hizmetlerimizden yararlanmak için hemen randevu alın.')
        ];
    } elseif ($page === 'about') {
        $textSettings = [
            'about_title' => sanitize($_POST['about_title'] ?? 'Hakkımızda'),
            'about_subtitle' => sanitize($_POST['about_subtitle'] ?? 'Yılların deneyimi ve ustalıkla size hizmet ediyoruz.'),
            'story_title' => sanitize($_POST['story_title'] ?? '30 Yıllık Tecrübe'),
            'story_text_1' => sanitize($_POST['story_text_1'] ?? '1985 yılından bu yana, aile geleneğini sürdürerek dikiş sektöründe hizmet veriyoruz. Babamızdan öğrendiğimiz ustalığı, kendi vizyonumuzla birleştirerek modern dikiş tekniklerini geleneksel el işçiliğiyle harmanladık.'),
            'story_text_2' => sanitize($_POST['story_text_2'] ?? 'Atölyemizde her bir kıyafet, özenle seçilen kumaşlar ve usta ellerimizle size özel olarak dikilir. Müşteri memnuniyeti bizim için en önemli önceliktir.'),
            'story_text_3' => sanitize($_POST['story_text_3'] ?? 'Bugün, üçüncü kuşak olarak aynı tutkuyla çalışmaya devam ediyoruz. Her geçen gün kendimizi geliştirerek, size daha iyi hizmet sunmayı hedefliyoruz.'),
            'values_title' => sanitize($_POST['values_title'] ?? 'Bizi Ayıran Özellikler'),
            'team_title' => sanitize($_POST['team_title'] ?? 'Ustalarımız'),
            'team_subtitle' => sanitize($_POST['team_subtitle'] ?? 'Deneyimli ve profesyonel ekibimizle tanışın.'),
            'team_1_name' => sanitize($_POST['team_1_name'] ?? 'Ahmet Yılmaz'),
            'team_1_role' => sanitize($_POST['team_1_role'] ?? 'Baş Usta'),
            'team_1_desc' => sanitize($_POST['team_1_desc'] ?? '35 yıllık tecrübe ile atölyemizin baş ustası.'),
            'team_2_name' => sanitize($_POST['team_2_name'] ?? 'Ayşe Demir'),
            'team_2_role' => sanitize($_POST['team_2_role'] ?? 'Dikiş Ustası'),
            'team_2_desc' => sanitize($_POST['team_2_desc'] ?? 'İnce işçilik ve detay konusunda uzman.'),
            'team_3_name' => sanitize($_POST['team_3_name'] ?? 'Mehmet Kaya'),
            'team_3_role' => sanitize($_POST['team_3_role'] ?? 'Ölçü Ustası'),
            'team_3_desc' => sanitize($_POST['team_3_desc'] ?? 'Özel ölçü ve kumaş seçimi konusunda uzman.'),
            'about_cta_title' => sanitize($_POST['about_cta_title'] ?? 'Bizimle Tanışın'),
            'about_cta_subtitle' => sanitize($_POST['about_cta_subtitle'] ?? 'Atölyemizi ziyaret edin ve hizmetlerimizi yakından görün.')
        ];
    } elseif ($page === 'contact') {
        $textSettings = [
            'contact_title' => sanitize($_POST['contact_title'] ?? 'İletişim'),
            'contact_subtitle' => sanitize($_POST['contact_subtitle'] ?? 'Bizimle iletişime geçin, size yardımcı olalım.'),
            'contact_section_title' => sanitize($_POST['contact_section_title'] ?? 'İletişim Bilgileri'),
            'contact_cta_title' => sanitize($_POST['contact_cta_title'] ?? 'Hemen Randevu Alın'),
            'contact_cta_subtitle' => sanitize($_POST['contact_cta_subtitle'] ?? 'Size özel dikiş hizmetlerimizden yararlanmak için hemen randevu alın.')
        ];
    }
    
    if (isset($textSettings)) {
        foreach ($textSettings as $key => $value) {
            setThemeSetting($theme['id'], $key, $value);
        }
    }
    
    $success = 'Ayarlar başarıyla güncellendi.';
}

$page = $_GET['page'] ?? 'home';
$pageTitles = [
    'home' => 'Ana Sayfa Ayarları',
    'about' => 'Hakkımızda Ayarları',
    'contact' => 'İletişim Ayarları',
    'settings' => 'Site Ayarları'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tema Admin | <?php echo $theme['name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Montserrat:wght@300;400;500;600&display=swap');
        
        body { 
            background: #f8f9fa; 
            font-family: 'Montserrat', sans-serif;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        
        .sidebar a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            padding: 1rem 1.5rem;
            display: block;
            margin: 0.25rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .sidebar a:hover, .sidebar a.active {
            background: rgba(201, 169, 98, 0.2);
            color: #c9a962;
        }
        
        .sidebar a i { 
            margin-right: 0.75rem; 
            width: 20px;
            color: #c9a962;
        }
        
        .card {
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            border: none;
        }
        
        .card-header {
            background: linear-gradient(135deg, #c9a962 0%, #d4af37 100%);
            color: #1a1a2e;
            border-radius: 20px 20px 0 0 !important;
            padding: 1.5rem;
        }
        
        .card-header h5 {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            font-size: 1.3rem;
        }
        
        .form-label {
            font-weight: 600;
            color: #1a1a2e;
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-control-color {
            border-radius: 12px;
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
        }
        
        .form-control:focus {
            border-color: #c9a962;
            box-shadow: 0 0 0 0.2rem rgba(201, 169, 98, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #c9a962 0%, #d4af37 100%);
            border: none;
            border-radius: 12px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            color: #1a1a2e;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #d4af37 0%, #c9a962 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(201, 169, 98, 0.4);
        }
        
        .image-preview {
            max-width: 150px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .section-divider {
            border-top: 2px solid #e9ecef;
            margin: 2rem 0;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar">
                <div class="text-center mb-5">
                    <i class="fas fa-scissors fa-3x mb-3" style="color: #c9a962;"></i>
                    <h5 class="text-white" style="font-family: 'Playfair Display', serif;"><?php echo $theme['name']; ?></h5>
                    <small class="text-white-50">v<?php echo $theme['version']; ?></small>
                </div>
                
                <a href="index.php?page=home" class="<?php echo $page === 'home' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Ana Sayfa
                </a>
                <a href="index.php?page=about" class="<?php echo $page === 'about' ? 'active' : ''; ?>">
                    <i class="fas fa-info-circle"></i> Hakkımızda
                </a>
                <a href="index.php?page=contact" class="<?php echo $page === 'contact' ? 'active' : ''; ?>">
                    <i class="fas fa-envelope"></i> İletişim
                </a>
                <a href="index.php?page=settings" class="<?php echo $page === 'settings' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i> Site Ayarları
                </a>
                
                <div class="mt-5">
                    <a href="<?php echo APP_URL; ?>/admin/dashboard.php">
                        <i class="fas fa-arrow-left"></i> Ana Admin
                    </a>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 style="font-family: 'Playfair Display', serif; font-weight: 700; color: #1a1a2e;">
                        <?php echo $pageTitles[$page] ?? 'Tema Ayarları'; ?>
                    </h2>
                    <a href="<?php echo APP_URL; ?>" target="_blank" class="btn btn-outline-primary" style="border-color: #c9a962; color: #c9a962;">
                        <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                    </a>
                </div>
                
                <?php if ($success): ?>
                    <div class="alert alert-success" style="border-radius: 12px;">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <!-- HOME PAGE SETTINGS -->
                <?php if ($page === 'home'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-home"></i> Ana Sayfa İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="home">
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-image"></i> Hero Bölümü
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Ana Başlık</label>
                                    <input type="text" name="hero_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title', 'Size Özel'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Renkli Span</label>
                                    <input type="text" name="hero_title_span" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'hero_title_span', 'Dikiş Hizmetleri'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="hero_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'hero_subtitle', 'Ustalık ve kalitenin buluştuğu noktada, size özel dikiş çözümleri sunuyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-star"></i> Özellikler Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Bölüm Başlığı</label>
                                <input type="text" name="features_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'features_title', 'Kalite ve Güven'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Alt Başlık</label>
                                <textarea name="features_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'features_subtitle', 'Yılların deneyimi ve profesyonel ekibimizle size en iyi hizmeti sunuyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-cut"></i> Hizmetler Bölümü
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Bölüm Başlığı</label>
                                    <input type="text" name="services_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'services_title', 'Size Özel Hizmetler'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="services_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'services_subtitle', 'İhtiyaçlarınıza uygun profesyonel dikiş hizmetleri sunuyoruz.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-concierge-bell"></i> Hizmet 1
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="service_1_image" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'service_1_image'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Başlık</label>
                                    <input type="text" name="service_1_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'service_1_title', 'Takım Elbise Dikimi'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Fiyat</label>
                                    <input type="text" name="service_1_price" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'service_1_price', '₺500\'den başlayan'); ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Açıklama</label>
                                <textarea name="service_1_desc" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'service_1_desc', 'Özel ölçüde, size uygun takım elbise dikimi. Kumaş seçimi dahil.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-concierge-bell"></i> Hizmet 2
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="service_2_image" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'service_2_image'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Başlık</label>
                                    <input type="text" name="service_2_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'service_2_title', 'Kıyafet Tamiri'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Fiyat</label>
                                    <input type="text" name="service_2_price" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'service_2_price', '₺200\'den başlayan'); ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Açıklama</label>
                                <textarea name="service_2_desc" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'service_2_desc', 'Kıyafetlerinizin tamiri, boyu ayarlama ve değişiklik işlemleri.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-concierge-bell"></i> Hizmet 3
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="service_3_image" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'service_3_image'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Başlık</label>
                                    <input type="text" name="service_3_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'service_3_title', 'Özel Dikim'); ?>">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Fiyat</label>
                                    <input type="text" name="service_3_price" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'service_3_price', '₺150\'den başlayan'); ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Açıklama</label>
                                <textarea name="service_3_desc" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'service_3_desc', 'Özel tasarımlarınız için profesyonel dikim hizmeti.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-images"></i> Galeri Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Galeri Başlığı</label>
                                <input type="text" name="gallery_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'gallery_title', 'Çalışmalarımız'); ?>">
                            </div>
                            
                            <div class="row">
                                <?php for ($i = 1; $i <= 6; $i++): ?>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Görsel <?php echo $i; ?></label>
                                    <input type="file" name="gallery_<?php echo $i; ?>" class="form-control" accept="image/*">
                                    <?php $galleryImg = getThemeSetting($theme['id'], 'gallery_' . $i); ?>
                                    <?php if ($galleryImg): ?>
                                        <img src="<?php echo getImageUrl($galleryImg); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <?php endfor; ?>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-comments"></i> Müşteri Yorumları
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Bölüm Başlığı</label>
                                    <input type="text" name="testimonials_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'testimonials_title', 'Ne Diyorlar?'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="testimonials_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'testimonials_subtitle', 'Müşterilerimizin deneyimleri ve geri bildirimleri.'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Yorum 1</label>
                                <textarea name="testimonial_1" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'testimonial_1', 'Harika bir işçilik! Takım elbitem tam istediğim gibi oldu. Kesinlikle tavsiye ederim.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Yorum 2</label>
                                <textarea name="testimonial_2" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'testimonial_2', 'Hızlı ve kaliteli hizmet. Kıyafetlerimin tamiri için her zaman burayı tercih ediyorum.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Yorum 3</label>
                                <textarea name="testimonial_3" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'testimonial_3', 'Profesyonel ekip ve güler yüzlü hizmet. Düğünüm için özel dikim yaptırdım, çok memnun kaldım.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-bullhorn"></i> CTA Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'cta_title', 'Hayalinizdeki Kıyafet İçin Randevu Alın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'cta_subtitle', 'Size özel dikiş hizmetlerimizden yararlanmak için hemen randevu alın.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- ABOUT PAGE SETTINGS -->
                <?php elseif ($page === 'about'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-info-circle"></i> Hakkımızda İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="about">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Sayfa Başlığı</label>
                                    <input type="text" name="about_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_title', 'Hakkımızda'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="about_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_subtitle', 'Yılların deneyimi ve ustalıkla size hizmet ediyoruz.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-history"></i> Hikayemiz
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Görsel</label>
                                <input type="file" name="about_image" class="form-control" accept="image/*">
                                <?php $aboutImg = getThemeSetting($theme['id'], 'about_image'); ?>
                                <?php if ($aboutImg): ?>
                                    <img src="<?php echo getImageUrl($aboutImg); ?>" class="image-preview mt-2">
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Bölüm Başlığı</label>
                                <input type="text" name="story_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'story_title', '30 Yıllık Tecrübe'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 1</label>
                                <textarea name="story_text_1" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'story_text_1', '1985 yılından bu yana, aile geleneğini sürdürerek dikiş sektöründe hizmet veriyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 2</label>
                                <textarea name="story_text_2" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'story_text_2', 'Atölyemizde her bir kıyafet, özenle seçilen kumaşlar ve usta ellerimizle size özel olarak dikilir.'); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Paragraf 3</label>
                                <textarea name="story_text_3" class="form-control" rows="3"><?php echo getThemeSetting($theme['id'], 'story_text_3', 'Bugün, üçüncü kuşak olarak aynı tutkuyla çalışmaya devam ediyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-heart"></i> Değerlerimiz Başlığı
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Başlık</label>
                                <input type="text" name="values_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'values_title', 'Bizi Ayıran Özellikler'); ?>">
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-users"></i> Ekibimiz
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Bölüm Başlığı</label>
                                    <input type="text" name="team_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_title', 'Ustalarımız'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Alt Başlık</label>
                                    <input type="text" name="team_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_subtitle', 'Deneyimli ve profesyonel ekibimizle tanışın.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-user"></i> Ekip Üyesi 1
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="team_1_image" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'team_1_image'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">İsim</label>
                                    <input type="text" name="team_1_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_1_name', 'Ahmet Yılmaz'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Unvan</label>
                                    <input type="text" name="team_1_role" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_1_role', 'Baş Usta'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Açıklama</label>
                                    <input type="text" name="team_1_desc" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_1_desc', '35 yıllık tecrübe ile atölyemizin baş ustası.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-user"></i> Ekip Üyesi 2
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="team_2_image" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'team_2_image'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">İsim</label>
                                    <input type="text" name="team_2_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_2_name', 'Ayşe Demir'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Unvan</label>
                                    <input type="text" name="team_2_role" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_2_role', 'Dikiş Ustası'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Açıklama</label>
                                    <input type="text" name="team_2_desc" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_2_desc', 'İnce işçilik ve detay konusunda uzman.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-user"></i> Ekip Üyesi 3
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Görsel</label>
                                    <input type="file" name="team_3_image" class="form-control" accept="image/*">
                                    <?php $img = getThemeSetting($theme['id'], 'team_3_image'); ?>
                                    <?php if ($img): ?>
                                        <img src="<?php echo getImageUrl($img); ?>" class="image-preview mt-2">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">İsim</label>
                                    <input type="text" name="team_3_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_3_name', 'Mehmet Kaya'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Unvan</label>
                                    <input type="text" name="team_3_role" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_3_role', 'Ölçü Ustası'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Açıklama</label>
                                    <input type="text" name="team_3_desc" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'team_3_desc', 'Özel ölçü ve kumaş seçimi konusunda uzman.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-bullhorn"></i> CTA Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="about_cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'about_cta_title', 'Bizimle Tanışın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="about_cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'about_cta_subtitle', 'Atölyemizi ziyaret edin ve hizmetlerimizi yakından görün.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- CONTACT PAGE SETTINGS -->
                <?php elseif ($page === 'contact'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-envelope"></i> İletişim İçerikleri</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="">
                            <input type="hidden" name="current_page" value="contact">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Sayfa Başlığı</label>
                                    <input type="text" name="contact_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'contact_title', 'İletişim'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Sayfa Alt Başlığı</label>
                                    <input type="text" name="contact_subtitle" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'contact_subtitle', 'Bizimle iletişime geçin, size yardımcı olalım.'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-bullhorn"></i> CTA Bölümü
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Başlık</label>
                                <input type="text" name="contact_cta_title" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'contact_cta_title', 'Hemen Randevu Alın'); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">CTA Alt Başlık</label>
                                <textarea name="contact_cta_subtitle" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'contact_cta_subtitle', 'Size özel dikiş hizmetlerimizden yararlanmak için hemen randevu alın.'); ?></textarea>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- SITE SETTINGS -->
                <?php elseif ($page === 'settings'): ?>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-cog"></i> Genel Site Ayarları</h5>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <input type="hidden" name="current_page" value="settings">
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-palette"></i> Renk Ayarları
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Ana Renk (Altın)</label>
                                    <input type="color" name="primary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'primary_color', '#c9a962'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">İkincil Renk (Koyu)</label>
                                    <input type="color" name="secondary_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'secondary_color', '#1a1a2e'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Vurgu Rengi (Aksan)</label>
                                    <input type="color" name="accent_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'accent_color', '#e94560'); ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="form-label">Altın Rengi</label>
                                    <input type="color" name="gold_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'gold_color', '#d4af37'); ?>">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Krem Rengi</label>
                                    <input type="color" name="cream_color" class="form-control form-control-color" value="<?php echo getThemeSetting($theme['id'], 'cream_color', '#f5f0e1'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-info-circle"></i> Site Bilgileri
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Site Adı</label>
                                    <input type="text" name="site_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'site_name', 'Elegant Tailor'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Marka Adı</label>
                                    <input type="text" name="brand_name" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'brand_name', 'Elegant Tailor'); ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Footer Açıklaması</label>
                                <textarea name="footer_description" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'footer_description', 'Yılların deneyimi ve ustalığı ile size özel dikiş hizmetleri sunuyoruz.'); ?></textarea>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-address-card"></i> İletişim Bilgileri
                            </h6>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Telefon</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'phone', '+90 212 555 5555'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">E-posta</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'email', 'info@eleganttailor.com'); ?>">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Adres</label>
                                    <textarea name="address" class="form-control" rows="2"><?php echo getThemeSetting($theme['id'], 'address', 'İstanbul, Türkiye'); ?></textarea>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Çalışma Saatleri</label>
                                    <input type="text" name="working_hours" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'working_hours', 'Pzt-Cmt: 09:00 - 19:00'); ?>">
                                </div>
                            </div>
                            
                            <div class="section-divider"></div>
                            
                            <h6 style="color: #c9a962; font-weight: 700; margin-bottom: 1.5rem;">
                                <i class="fas fa-link"></i> Linkler
                            </h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Randevu Linki</label>
                                <input type="text" name="booking_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>">
                                <small class="text-muted">Randevu butonuna tıklandığında yönlendirilecek link</small>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Facebook Linki</label>
                                    <input type="text" name="facebook_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'facebook_link', '#'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Instagram Linki</label>
                                    <input type="text" name="instagram_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'instagram_link', '#'); ?>">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Twitter Linki</label>
                                    <input type="text" name="twitter_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'twitter_link', '#'); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">LinkedIn Linki</label>
                                    <input type="text" name="linkedin_link" class="form-control" value="<?php echo getThemeSetting($theme['id'], 'linkedin_link', '#'); ?>">
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-save"></i> Ayarları Kaydet
                            </button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
