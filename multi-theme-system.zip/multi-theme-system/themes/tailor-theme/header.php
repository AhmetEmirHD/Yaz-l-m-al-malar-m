<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' : ''; ?><?php echo getThemeSetting($theme['id'], 'site_name', 'Elegant Tailor'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Segoe+UI:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: <?php echo getThemeSetting($theme['id'], 'primary_color', '#c9a962'); ?>;
            --primary-light: <?php echo getThemeSetting($theme['id'], 'primary_color', '#e8d5a3'); ?>;
            --primary-dark: <?php echo getThemeSetting($theme['id'], 'primary_color', '#8b7355'); ?>;
            --secondary: <?php echo getThemeSetting($theme['id'], 'secondary_color', '#1a1a2e'); ?>;
            --secondary-light: <?php echo getThemeSetting($theme['id'], 'secondary_color', '#2c2c44'); ?>;
            --accent: <?php echo getThemeSetting($theme['id'], 'accent_color', '#e94560'); ?>;
            --gold: <?php echo getThemeSetting($theme['id'], 'gold_color', '#d4af37'); ?>;
            --cream: <?php echo getThemeSetting($theme['id'], 'cream_color', '#f5f0e1'); ?>;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar" id="navbar">
        <div class="container">
            <a href="/multi-theme-system" class="navbar-brand">
                <i class="fas fa-scissors"></i>
                <span><?php echo getThemeSetting($theme['id'], 'brand_name', 'Elegant Tailor'); ?></span>
            </a>
            <ul class="navbar-nav">
                <li><a href="/multi-theme-system">Ana Sayfa</a></li>
                <li><a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/about.php">Hakkımızda</a></li>
                <li><a href="#services">Hizmetler</a></li>
                <li><a href="#gallery">Galeri</a></li>
                <li><a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/contact.php">İletişim</a></li>
                <li><a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn btn-primary" style="padding: 8px 20px; font-size: 0.85rem;">
                    <i class="fas fa-calendar-alt"></i> Randevu Al
                </a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    </script>
