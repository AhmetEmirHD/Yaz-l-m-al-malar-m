<?php
/**
 * Tailor Theme - About Page
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('tailor-theme');
$pageTitle = 'Hakkımızda';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- About Hero Section -->
<section class="hero" style="height: 60vh; min-height: 400px;">
    <div class="container">
        <div class="hero-content">
            <h1><?php echo getThemeSetting($theme['id'], 'about_title', 'Hakkımızda'); ?></h1>
            <p><?php echo getThemeSetting($theme['id'], 'about_subtitle', 'Yılların deneyimi ve ustalıkla size hizmet ediyoruz.'); ?></p>
        </div>
    </div>
</section>

<!-- About Content Section -->
<section class="services">
    <div class="container">
        <div class="section-header">
            <h6>Hikayemiz</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'story_title', '30 Yıllık Tecrübe'); ?></h2>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 50px; align-items: center;">
            <div>
                <img src="<?php echo getImageUrl(getThemeSetting($theme['id'], 'about_image')) ?: 'https://images.unsplash.com/photo-1558171813-4c088753af8f?w=600'; ?>" alt="Atölyemiz" style="border-radius: 10px; box-shadow: var(--shadow-xl);">
            </div>
            <div>
                <p style="font-size: 1.1rem; line-height: 1.8; margin-bottom: 20px;">
                    <?php echo getThemeSetting($theme['id'], 'story_text_1', '1985 yılından bu yana, aile geleneğini sürdürerek dikiş sektöründe hizmet veriyoruz. Babamızdan öğrendiğimiz ustalığı, kendi vizyonumuzla birleştirerek modern dikiş tekniklerini geleneksel el işçiliğiyle harmanladık.'); ?>
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8; margin-bottom: 20px;">
                    <?php echo getThemeSetting($theme['id'], 'story_text_2', 'Atölyemizde her bir kıyafet, özenle seçilen kumaşlar ve usta ellerimizle size özel olarak dikilir. Müşteri memnuniyeti bizim için en önemli önceliktir.'); ?>
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8;">
                    <?php echo getThemeSetting($theme['id'], 'story_text_3', 'Bugün, üçüncü kuşak olarak aynı tutkuyla çalışmaya devam ediyoruz. Her geçen gün kendimizi geliştirerek, size daha iyi hizmet sunmayı hedefliyoruz.'); ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Values Section -->
<section class="features">
    <div class="container">
        <div class="section-header">
            <h6>Değerlerimiz</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'values_title', 'Bizi Ayıran Özellikler'); ?></h2>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-heart"></i>
                </div>
                <h3>Tutku</h3>
                <p>Yaptığımız her işe aynı tutku ve özenle yaklaşıyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-medal"></i>
                </div>
                <h3>Kalite</h3>
                <p>En kaliteli malzemeleri kullanarak mükemmel sonuçlar hedefliyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h3>Güven</h3>
                <p>Müşterilerimizin güvenini kazanmak ve korumak bizim görevimiz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-lightbulb"></i>
                </div>
                <h3>Yenilikçilik</h3>
                <p>Modern teknikleri takip ederek hizmetlerimizi sürekli geliştiriyoruz.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-handshake"></i>
                </div>
                <h3>Dürüstlük</h3>
                <p>Tekliflerimiz ve işçiliğimiz konusunda her zaman şeffafız.</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3>Zamanında Teslim</h3>
                <p>Taahhüt ettiğimiz sürelerde işimizi zamanında teslim ediyoruz.</p>
            </div>
        </div>
    </div>
</section>

<!-- Team Section -->
<section class="services">
    <div class="container">
        <div class="section-header">
            <h6>Ekibimiz</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'team_title', 'Ustalarımız'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'team_subtitle', 'Deneyimli ve profesyonel ekibimizle tanışın.'); ?></p>
        </div>
        
        <div class="services-grid">
            <div class="service-card" style="text-align: center;">
                <div class="service-image" style="background-image: url('<?php echo getImageUrl(getThemeSetting($theme['id'], 'team_1_image')) ?: 'https://randomuser.me/api/portraits/men/75.jpg'; ?>'); height: 300px; background-position: center;">
                </div>
                <div class="service-content">
                    <h3><?php echo getThemeSetting($theme['id'], 'team_1_name', 'Ahmet Yılmaz'); ?></h3>
                    <p style="color: var(--primary); font-weight: 600;"><?php echo getThemeSetting($theme['id'], 'team_1_role', 'Baş Usta'); ?></p>
                    <p><?php echo getThemeSetting($theme['id'], 'team_1_desc', '35 yıllık tecrübe ile atölyemizin baş ustası.'); ?></p>
                </div>
            </div>
            
            <div class="service-card" style="text-align: center;">
                <div class="service-image" style="background-image: url('<?php echo getImageUrl(getThemeSetting($theme['id'], 'team_2_image')) ?: 'https://randomuser.me/api/portraits/women/65.jpg'; ?>'); height: 300px; background-position: center;">
                </div>
                <div class="service-content">
                    <h3><?php echo getThemeSetting($theme['id'], 'team_2_name', 'Ayşe Demir'); ?></h3>
                    <p style="color: var(--primary); font-weight: 600;"><?php echo getThemeSetting($theme['id'], 'team_2_role', 'Dikiş Ustası'); ?></p>
                    <p><?php echo getThemeSetting($theme['id'], 'team_2_desc', 'İnce işçilik ve detay konusunda uzman.'); ?></p>
                </div>
            </div>
            
            <div class="service-card" style="text-align: center;">
                <div class="service-image" style="background-image: url('<?php echo getImageUrl(getThemeSetting($theme['id'], 'team_3_image')) ?: 'https://randomuser.me/api/portraits/men/45.jpg'; ?>'); height: 300px; background-position: center;">
                </div>
                <div class="service-content">
                    <h3><?php echo getThemeSetting($theme['id'], 'team_3_name', 'Mehmet Kaya'); ?></h3>
                    <p style="color: var(--primary); font-weight: 600;"><?php echo getThemeSetting($theme['id'], 'team_3_role', 'Ölçü Ustası'); ?></p>
                    <p><?php echo getThemeSetting($theme['id'], 'team_3_desc', 'Özel ölçü ve kumaş seçimi konusunda uzman.'); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="container">
        <div class="cta-content">
            <h2><?php echo getThemeSetting($theme['id'], 'about_cta_title', 'Bizimle Tanışın'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'about_cta_subtitle', 'Atölyemizi ziyaret edin ve hizmetlerimizi yakından görün.'); ?></p>
            <a href="/multi-theme-system/themes/<?php echo $theme['folder']; ?>/contact.php" class="btn">
                <i class="fas fa-envelope"></i> İletişime Geçin
            </a>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
