<?php
/**
 * Tailor Theme - Contact Page
 */

require_once __DIR__ . '/../../includes/functions.php';

// Get theme info
$theme = getThemeByFolder('tailor-theme');
$pageTitle = 'İletişim';

// Include header
include_once __DIR__ . '/header.php';
?>

<!-- Contact Hero Section -->
<section class="hero" style="height: 60vh; min-height: 400px;">
    <div class="container">
        <div class="hero-content">
            <h1><?php echo getThemeSetting($theme['id'], 'contact_title', 'İletişim'); ?></h1>
            <p><?php echo getThemeSetting($theme['id'], 'contact_subtitle', 'Bizimle iletişime geçin, size yardımcı olalım.'); ?></p>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section class="services">
    <div class="container">
        <div class="section-header">
            <h6>Bize Ulaşın</h6>
            <h2><?php echo getThemeSetting($theme['id'], 'contact_section_title', 'İletişim Bilgileri'); ?></h2>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 40px;">
            <!-- Contact Info -->
            <div>
                <div style="margin-bottom: 30px;">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
                        <div style="width: 50px; height: 50px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--white); font-size: 1.2rem;">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div>
                            <h4 style="margin-bottom: 5px;">Adres</h4>
                            <p style="margin: 0;"><?php echo getThemeSetting($theme['id'], 'address', 'İstanbul, Türkiye'); ?></p>
                        </div>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
                        <div style="width: 50px; height: 50px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--white); font-size: 1.2rem;">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div>
                            <h4 style="margin-bottom: 5px;">Telefon</h4>
                            <p style="margin: 0;"><?php echo getThemeSetting($theme['id'], 'phone', '+90 212 555 5555'); ?></p>
                        </div>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
                        <div style="width: 50px; height: 50px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--white); font-size: 1.2rem;">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div>
                            <h4 style="margin-bottom: 5px;">E-posta</h4>
                            <p style="margin: 0;"><?php echo getThemeSetting($theme['id'], 'email', 'info@eleganttailor.com'); ?></p>
                        </div>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 50px; height: 50px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--white); font-size: 1.2rem;">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div>
                            <h4 style="margin-bottom: 5px;">Çalışma Saatleri</h4>
                            <p style="margin: 0;"><?php echo getThemeSetting($theme['id'], 'working_hours', 'Pzt-Cmt: 09:00 - 19:00'); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Social Links -->
                <div style="margin-top: 30px;">
                    <h4 style="margin-bottom: 20px;">Bizi Takip Edin</h4>
                    <div style="display: flex; gap: 15px;">
                        <a href="<?php echo getThemeSetting($theme['id'], 'facebook_link', '#'); ?>" style="width: 45px; height: 45px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--white); font-size: 1.2rem; transition: var(--transition);">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="<?php echo getThemeSetting($theme['id'], 'instagram_link', '#'); ?>" style="width: 45px; height: 45px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--white); font-size: 1.2rem; transition: var(--transition);">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="<?php echo getThemeSetting($theme['id'], 'twitter_link', '#'); ?>" style="width: 45px; height: 45px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--white); font-size: 1.2rem; transition: var(--transition);">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="<?php echo getThemeSetting($theme['id'], 'linkedin_link', '#'); ?>" style="width: 45px; height: 45px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--white); font-size: 1.2rem; transition: var(--transition);">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Contact Form -->
            <div style="background: var(--white); padding: 40px; border-radius: 10px; box-shadow: var(--shadow-lg);">
                <h3 style="margin-bottom: 25px;">Mesaj Gönderin</h3>
                <form>
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600;">Adınız</label>
                        <input type="text" placeholder="Adınız Soyadınız" style="width: 100%; padding: 12px 15px; border: 2px solid var(--gray-light); border-radius: 5px; font-size: 1rem; transition: var(--transition);">
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600;">E-posta</label>
                        <input type="email" placeholder="E-posta adresiniz" style="width: 100%; padding: 12px 15px; border: 2px solid var(--gray-light); border-radius: 5px; font-size: 1rem; transition: var(--transition);">
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600;">Telefon</label>
                        <input type="tel" placeholder="Telefon numaranız" style="width: 100%; padding: 12px 15px; border: 2px solid var(--gray-light); border-radius: 5px; font-size: 1rem; transition: var(--transition);">
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600;">Konu</label>
                        <input type="text" placeholder="Mesaj konusu" style="width: 100%; padding: 12px 15px; border: 2px solid var(--gray-light); border-radius: 5px; font-size: 1rem; transition: var(--transition);">
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 600;">Mesajınız</label>
                        <textarea rows="5" placeholder="Mesajınızı buraya yazın..." style="width: 100%; padding: 12px 15px; border: 2px solid var(--gray-light); border-radius: 5px; font-size: 1rem; transition: var(--transition); resize: vertical;"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-paper-plane"></i> Mesaj Gönder
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<section style="padding: 0;">
    <div style="width: 100%; height: 400px; background: var(--gray-light); display: flex; align-items: center; justify-content: center;">
        <div style="text-align: center; color: var(--gray);">
            <i class="fas fa-map-marked-alt" style="font-size: 3rem; margin-bottom: 20px;"></i>
            <p>Harita entegrasyonu için Google Maps API anahtarı gereklidir</p>
            <p style="font-size: 0.9rem; margin-top: 10px;">Adres: <?php echo getThemeSetting($theme['id'], 'address', 'İstanbul, Türkiye'); ?></p>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta">
    <div class="container">
        <div class="cta-content">
            <h2><?php echo getThemeSetting($theme['id'], 'contact_cta_title', 'Hemen Randevu Alın'); ?></h2>
            <p><?php echo getThemeSetting($theme['id'], 'contact_cta_subtitle', 'Size özel dikiş hizmetlerimizden yararlanmak için hemen randevu alın.'); ?></p>
            <a href="<?php echo getThemeSetting($theme['id'], 'booking_link', '#'); ?>" class="btn">
                <i class="fas fa-calendar-alt"></i> Randevu Al
            </a>
        </div>
    </div>
</section>

<?php
// Include footer
include_once __DIR__ . '/footer.php';
?>
