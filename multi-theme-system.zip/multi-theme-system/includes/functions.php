<?php
/**
 * Helper Functions
 * Multi-Theme System
 */

require_once __DIR__ . '/../config/database.php';

/**
 * Sanitize input data
 */
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Get active theme
 */
function getActiveTheme() {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM themes WHERE is_active = 1 LIMIT 1");
    $stmt->execute();
    return $stmt->fetch();
}

/**
 * Get theme by folder name
 */
function getThemeByFolder($folder) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM themes WHERE folder = ?");
    $stmt->execute([$folder]);
    return $stmt->fetch();
}

/**
 * Get all themes
 */
function getAllThemes() {
    $db = getDB();
    return $db->query("SELECT * FROM themes ORDER BY name ASC")->fetchAll();
}

/**
 * Get theme setting
 */
function getThemeSetting($themeId, $key, $default = '') {
    $db = getDB();
    $stmt = $db->prepare("SELECT setting_value FROM theme_settings WHERE theme_id = ? AND setting_key = ?");
    $stmt->execute([$themeId, $key]);
    $result = $stmt->fetch();
    return $result ? $result['setting_value'] : $default;
}

/**
 * Set theme setting
 */
function setThemeSetting($themeId, $key, $value) {
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM theme_settings WHERE theme_id = ? AND setting_key = ?");
    $stmt->execute([$themeId, $key]);
    
    if ($stmt->fetch()) {
        // Update
        $stmt = $db->prepare("UPDATE theme_settings SET setting_value = ? WHERE theme_id = ? AND setting_key = ?");
        $stmt->execute([$value, $themeId, $key]);
    } else {
        // Insert
        $stmt = $db->prepare("INSERT INTO theme_settings (theme_id, setting_key, setting_value) VALUES (?, ?, ?)");
        $stmt->execute([$themeId, $key, $value]);
    }
}

/**
 * Activate theme
 */
function activateTheme($themeId) {
    $db = getDB();
    
    // Deactivate all themes
    $db->query("UPDATE themes SET is_active = 0");
    
    // Activate selected theme
    $stmt = $db->prepare("UPDATE themes SET is_active = 1 WHERE id = ?");
    $stmt->execute([$themeId]);
    
    return true;
}

/**
 * Get theme config from theme.json
 */
function getThemeConfig($folder) {
    $configFile = THEMES_DIR . '/' . $folder . '/theme.json';
    
    if (!file_exists($configFile)) {
        return null;
    }
    
    $content = file_get_contents($configFile);
    return json_decode($content, true);
}

/**
 * Check if theme has admin panel
 */
function themeHasAdmin($folder) {
    $config = getThemeConfig($folder);
    return $config && isset($config['has_admin']) && $config['has_admin'] === true;
}

/**
 * Upload theme from ZIP
 */
function uploadTheme($zipFile) {
    $tempDir = sys_get_temp_dir() . '/theme_upload_' . time();
    mkdir($tempDir, 0777, true);
    
    // Extract ZIP
    $zip = new ZipArchive;
    if ($zip->open($zipFile) !== TRUE) {
        return false;
    }
    
    $zip->extractTo($tempDir);
    $zip->close();
    
    // Find theme folder (should contain theme.json)
    $themeFolder = null;
    $dirs = glob($tempDir . '/*', GLOB_ONLYDIR);
    
    foreach ($dirs as $dir) {
        if (file_exists($dir . '/theme.json')) {
            $themeFolder = basename($dir);
            break;
        }
    }
    
    if (!$themeFolder) {
        // Check if root is theme folder
        if (file_exists($tempDir . '/theme.json')) {
            $themeFolder = basename($zipFile, '.zip');
            $targetDir = THEMES_DIR . '/' . $themeFolder;
            
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0777, true);
            }
            
            // Move files
            foreach (glob($tempDir . '/*') as $file) {
                rename($file, $targetDir . '/' . basename($file));
            }
        } else {
            return false;
        }
    } else {
        // Move theme folder
        $targetDir = THEMES_DIR . '/' . $themeFolder;
        if (is_dir($targetDir)) {
            rmdir_recursive($targetDir);
        }
        rename($tempDir . '/' . $themeFolder, $targetDir);
    }
    
    // Clean temp
    rmdir_recursive($tempDir);
    
    // Register in database
    $config = getThemeConfig($themeFolder);
    if ($config) {
        $db = getDB();
        
        // Check if theme exists
        $stmt = $db->prepare("SELECT id FROM themes WHERE folder = ?");
        $stmt->execute([$themeFolder]);
        
        if (!$stmt->fetch()) {
            $stmt = $db->prepare("INSERT INTO themes (name, description, folder, version, is_active) VALUES (?, ?, ?, ?, 0)");
            $stmt->execute([
                $config['name'],
                $config['description'] ?? '',
                $themeFolder,
                $config['version'] ?? '1.0.0'
            ]);
        }
    }
    
    return $themeFolder;
}

/**
 * Recursive directory delete
 */
function rmdir_recursive($dir) {
    if (!is_dir($dir)) {
        return;
    }
    
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        is_dir($path) ? rmdir_recursive($path) : unlink($path);
    }
    rmdir($dir);
}

/**
 * Delete theme
 */
function deleteTheme($themeId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT folder, is_active FROM themes WHERE id = ?");
    $stmt->execute([$themeId]);
    $theme = $stmt->fetch();
    
    if (!$theme) {
        return false;
    }
    
    // Cannot delete active theme
    if ($theme['is_active']) {
        return false;
    }
    
    // Delete folder
    $themePath = THEMES_DIR . '/' . $theme['folder'];
    if (is_dir($themePath)) {
        rmdir_recursive($themePath);
    }
    
    // Delete from database
    $stmt = $db->prepare("DELETE FROM theme_settings WHERE theme_id = ?");
    $stmt->execute([$themeId]);
    
    $stmt = $db->prepare("DELETE FROM themes WHERE id = ?");
    $stmt->execute([$themeId]);
    
    return true;
}

/**
 * Generate slug
 */
function generateSlug($text) {
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');
    return $text;
}

/**
 * Format date
 */
function formatDate($date, $format = 'd.m.Y H:i') {
    return date($format, strtotime($date));
}

/**
 * Check admin login
 */
function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

/**
 * Require admin login
 */
function requireAdminLogin() {
    if (!isAdminLoggedIn()) {
        header('Location: ' . APP_URL . '/admin/login.php');
        exit;
    }
}

/**
 * Upload image
 */
function uploadImage($file, $subfolder = '') {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($file['type'], $allowedTypes)) {
        return false;
    }
    
    $uploadDir = UPLOAD_DIR;
    if ($subfolder) {
        $uploadDir .= '/' . $subfolder;
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '.' . $extension;
    $filepath = $uploadDir . '/' . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $subfolder ? $subfolder . '/' . $filename : $filename;
    }
    
    return false;
}

/**
 * Get image URL
 */
function getImageUrl($imagePath) {
    if (!$imagePath) {
        return '';
    }
    return APP_URL . '/uploads/' . $imagePath;
}

/**
 * Delete image
 */
function deleteImage($imagePath) {
    if (!$imagePath) {
        return false;
    }
    
    $filepath = UPLOAD_DIR . '/' . $imagePath;
    if (file_exists($filepath)) {
        unlink($filepath);
        return true;
    }
    
    return false;
}
?>
