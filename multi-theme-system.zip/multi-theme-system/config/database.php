<?php
/**
 * Database Configuration
 * Multi-Theme System
 */

// Database Settings
define('DB_HOST', 'localhost');
define('DB_NAME', 'multi_theme_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// App Settings
define('APP_NAME', 'Multi-Theme System');
define('APP_URL', 'http://localhost/multi-theme-system');
define('ADMIN_EMAIL', 'admin@example.com');

// Theme Settings
define('THEMES_DIR', __DIR__ . '/../themes');
define('UPLOAD_DIR', __DIR__ . '/../uploads');

// Security
define('HASH_ALGO', PASSWORD_DEFAULT);

// Error Reporting (Development)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Europe/Istanbul');

/**
 * Get Database Connection (PDO)
 */
function getDB() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            die('Veritabanı Bağlantı Hatası: ' . $e->getMessage());
        }
    }
    
    return $pdo;
}
?>
