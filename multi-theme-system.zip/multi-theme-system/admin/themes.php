<?php
/**
 * Admin Theme Management
 */

session_start();
require_once __DIR__ . '/../includes/functions.php';

requireAdminLogin();

$db = getDB();
$success = '';
$error = '';

// Handle theme activation
if (isset($_GET['activate'])) {
    $themeId = (int)$_GET['activate'];
    activateTheme($themeId);
    $success = 'Tema başarıyla aktif edildi.';
    header('Location: themes.php?success=activated');
    exit;
}

// Handle theme deletion
if (isset($_GET['delete'])) {
    $themeId = (int)$_GET['delete'];
    if (deleteTheme($themeId)) {
        $success = 'Tema başarıyla silindi.';
    } else {
        $error = 'Tema silinemedi (aktif tema silinemez).';
    }
    header('Location: themes.php?' . ($success ? 'success=deleted' : 'error=delete_failed'));
    exit;
}

// Handle theme upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['theme_zip'])) {
    $zipFile = $_FILES['theme_zip']['tmp_name'];
    
    if ($_FILES['theme_zip']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Dosya yükleme hatası.';
    } else {
        $result = uploadTheme($zipFile);
        if ($result) {
            $success = 'Tema başarıyla yüklendi: ' . $result;
        } else {
            $error = 'Tema yüklenemedi. Geçersiz ZIP dosyası veya theme.json bulunamadı.';
        }
    }
}

// Get all themes
$themes = getAllThemes();
$activeTheme = getActiveTheme();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tema Yönetimi | <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 0.75rem 1.5rem;
            display: block;
            margin: 0.25rem 0;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.2);
        }
        .sidebar a i { margin-right: 0.75rem; width: 20px; }
        .theme-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            height: 100%;
            position: relative;
        }
        .theme-card.active {
            border: 3px solid #28a745;
        }
        .theme-card .badge-active {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: #28a745;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-layer-group fa-3x mb-2"></i>
                    <h5 class="text-white"><?php echo APP_NAME; ?></h5>
                </div>
                <a href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="themes.php" class="active">
                    <i class="fas fa-palette"></i> Tema Yönetimi
                </a>
                <a href="<?php echo APP_URL; ?>" target="_blank">
                    <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                </a>
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                </a>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Tema Yönetimi</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#uploadModal">
                        <i class="fas fa-upload"></i> Yeni Tema Yükle
                    </button>
                </div>
                
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> 
                        <?php 
                        if ($_GET['success'] === 'activated') echo 'Tema başarıyla aktif edildi.';
                        elseif ($_GET['success'] === 'deleted') echo 'Tema başarıyla silindi.';
                        ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> 
                        <?php 
                        if ($_GET['error'] === 'delete_failed') echo 'Tema silinemedi (aktif tema silinemez).';
                        ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Themes Grid -->
                <div class="row">
                    <?php if (empty($themes)): ?>
                        <div class="col-12">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> Henüz tema yüklenmedi. Yeni bir tema yükleyerek başlayın.
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($themes as $theme): ?>
                        <div class="col-md-4 mb-4">
                            <div class="theme-card <?php echo $theme['is_active'] ? 'active' : ''; ?>">
                                <?php if ($theme['is_active']): ?>
                                    <span class="badge-active">Aktif</span>
                                <?php endif; ?>
                                
                                <div class="text-center mb-3">
                                    <i class="fas fa-palette fa-4x text-muted"></i>
                                </div>
                                
                                <h4><?php echo $theme['name']; ?></h4>
                                <p class="text-muted small mb-2"><?php echo $theme['description'] ?? 'Açıklama yok'; ?></p>
                                
                                <div class="small text-muted mb-3">
                                    <div><strong>Klasör:</strong> <?php echo $theme['folder']; ?></div>
                                    <div><strong>Versiyon:</strong> <?php echo $theme['version']; ?></div>
                                    <div><strong>Admin:</strong> <?php echo themeHasAdmin($theme['folder']) ? '<i class="fas fa-check text-success"></i> Var' : '<i class="fas fa-times text-danger"></i> Yok'; ?></div>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <?php if (!$theme['is_active']): ?>
                                        <a href="?activate=<?php echo $theme['id']; ?>" class="btn btn-success btn-sm flex-grow-1">
                                            <i class="fas fa-check"></i> Aktif Et
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if (themeHasAdmin($theme['folder'])): ?>
                                        <a href="<?php echo APP_URL; ?>/themes/<?php echo $theme['folder']; ?>/admin/" class="btn btn-primary btn-sm flex-grow-1">
                                            <i class="fas fa-cog"></i> Admin
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if (!$theme['is_active']): ?>
                                        <a href="?delete=<?php echo $theme['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bu temayı silmek istediğinizden emin misiniz?');">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Upload Modal -->
    <div class="modal fade" id="uploadModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Yeni Tema Yükle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Tema ZIP Dosyası</label>
                            <input type="file" name="theme_zip" class="form-control" accept=".zip" required>
                            <small class="text-muted">ZIP dosyası theme.json içermelidir.</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-upload"></i> Yükle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
