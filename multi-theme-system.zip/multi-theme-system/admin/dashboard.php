<?php
/**
 * Admin Dashboard
 */

session_start();
require_once __DIR__ . '/../includes/functions.php';

requireAdminLogin();

$db = getDB();

// Get stats
$totalThemes = $db->query("SELECT COUNT(*) FROM themes")->fetchColumn();
$activeTheme = getActiveTheme();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 0.75rem 1.5rem;
            display: block;
            margin: 0.25rem 0;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.2);
        }
        .sidebar a i { margin-right: 0.75rem; width: 20px; }
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            border-left: 4px solid #667eea;
        }
        .stat-card h3 { font-size: 2.5rem; font-weight: 700; margin: 0; }
        .stat-card p { color: #6c757d; margin: 0; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar">
                <div class="text-center mb-4">
                    <i class="fas fa-layer-group fa-3x mb-2"></i>
                    <h5 class="text-white"><?php echo APP_NAME; ?></h5>
                </div>
                <a href="dashboard.php" class="active">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="themes.php">
                    <i class="fas fa-palette"></i> Tema Yönetimi
                </a>
                <a href="<?php echo APP_URL; ?>" target="_blank">
                    <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                </a>
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                </a>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Dashboard</h2>
                    <div>
                        <span class="text-muted">Hoş geldin, <?php echo $_SESSION['admin_name']; ?></span>
                    </div>
                </div>
                
                <!-- Stats -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="stat-card">
                            <h3><?php echo $totalThemes; ?></h3>
                            <p>Toplam Tema</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card" style="border-left-color: #28a745;">
                            <h3>1</h3>
                            <p>Aktif Tema</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card" style="border-left-color: #ffc107;">
                            <h3><?php echo $activeTheme ? $activeTheme['name'] : 'Yok'; ?></h3>
                            <p>Aktif Tema Adı</p>
                        </div>
                    </div>
                </div>
                
                <!-- Active Theme Info -->
                <?php if ($activeTheme): ?>
                <div class="card mb-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-check-circle text-success"></i> Aktif Tema</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h4><?php echo $activeTheme['name']; ?></h4>
                                <p class="text-muted"><?php echo $activeTheme['description'] ?? 'Açıklama yok'; ?></p>
                                <p><strong>Klasör:</strong> <?php echo $activeTheme['folder']; ?></p>
                                <p><strong>Versiyon:</strong> <?php echo $activeTheme['version']; ?></p>
                            </div>
                            <div class="col-md-6 text-end">
                                <a href="<?php echo APP_URL; ?>" target="_blank" class="btn btn-success mb-2">
                                    <i class="fas fa-external-link-alt"></i> Siteyi Görüntüle
                                </a>
                                <?php if (themeHasAdmin($activeTheme['folder'])): ?>
                                <a href="<?php echo APP_URL; ?>/themes/<?php echo $activeTheme['folder']; ?>/admin/" class="btn btn-primary">
                                    <i class="fas fa-cog"></i> Tema Adminine Git
                                </a>
                                <?php else: ?>
                                <button class="btn btn-secondary" disabled>
                                    <i class="fas fa-info-circle"></i> Admin Paneli Yok
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> Aktif tema bulunmuyor! <a href="themes.php">Tema yönetimi</a> sayfasından bir tema aktif edin.
                </div>
                <?php endif; ?>
                
                <!-- Quick Actions -->
                <div class="card">
                    <div class="card-header bg-white">
                        <h5 class="mb-0"><i class="fas fa-bolt"></i> Hızlı İşlemler</h5>
                    </div>
                    <div class="card-body">
                        <a href="themes.php" class="btn btn-outline-primary me-2">
                            <i class="fas fa-plus"></i> Yeni Tema Yükle
                        </a>
                        <a href="themes.php" class="btn btn-outline-secondary">
                            <i class="fas fa-list"></i> Temaları Listele
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
